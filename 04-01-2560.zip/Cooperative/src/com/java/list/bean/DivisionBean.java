package com.java.list.bean;

public class DivisionBean {
	
	private int id;
	private String Code;
	private String Name;
	private String Initials;
	private int facid;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCode() {
		return Code;
	}
	public void setCode(String code) {
		Code = code;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getInitials() {
		return Initials;
	}
	public void setInitials(String initials) {
		Initials = initials;
	}
	public int getFacID() {
		return facid;
	}
	public void setFacID(int facID) {
		facid = facID;
	}
	
	
	
}




package com.java.admin.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.admin.bean.FacultyBean;
import com.java.admin.dao.TableDivisionDao;
import com.java.admin.dao.TableFacultyDao;
import com.java.admin.dao.StudentDeleteUserDao;
import com.java.admin.dao.StudentUserDao;

import com.java.admin.bean.DivisionBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableUserDao;
import com.java.util.FileUploadUtil;

/**
 * Servlet implementation class StudentManagement
 */
@WebServlet("/StudentManagement")
public class StudentManagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentManagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		  
		  HttpSession session = request.getSession();
		  String role = session.getAttribute("role").toString();
		
		  // role admin
		  if(role.equals("2")){
				ArrayList<UserBean> userList = new ArrayList<UserBean>();
				ArrayList<FacultyBean> listFaclty = new ArrayList<FacultyBean>();
				
				StudentUserDao tableUserDao = new StudentUserDao();
				TableFacultyDao tableFacultyDao = new TableFacultyDao();

				userList = tableUserDao.getStudentUserList();
				listFaclty = tableFacultyDao.getFacultyList(); 

				request.setAttribute("userList", userList);
				request.setAttribute("listFaclty", listFaclty);
				
				doViewStudentManagement(request, response);
		  }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		ArrayList<DivisionBean> listDivision = new ArrayList<DivisionBean>();
		TableDivisionDao tableDivisionDao = new TableDivisionDao();
		PrintWriter out = response.getWriter();
		ArrayList<UserBean> userBeansList = new ArrayList<UserBean>();

		String action = request.getParameter("action");
		
		/* onchang select Fac to select Division  */
		if("Division".equals(action)){
			String searchAll = request.getParameter("search");
			String text = "";
			if("searchAll".equals(searchAll)){
				text = "���ҷ�����";
			}else{
				text = "==��س����͡�Ң�==";
			}
			int divid = Integer.parseInt(request.getParameter("divid"));
			listDivision = tableDivisionDao.getDivisionList(divid);
			if(!listDivision.isEmpty()){
				out.print("<option value='0' >"+text+"</option>");  
				for(DivisionBean item : listDivision){
					out.print("<option value="+item.getId()+">"+item.getName()+"</option>");  
				}
			}else{
				out.print("<option value='0' >"+text+"</option>");  
			}
		}
		/* # onchang select Fac to select Division  */
		
		/*  search  */
		else if("search".equals(action)){
			String check = request.getParameter("check");
			int facid = Integer.parseInt(request.getParameter("facid"));
			StudentUserDao tableUserDao = new StudentUserDao();
			if("searchFac".equals(check)){
				if(facid == 0){
					// * from student role 1  ���ҷ�����
					userBeansList = tableUserDao.getStudentUserList();
				}else{
					// other student  �������
					userBeansList = tableUserDao.getStudentUserList(facid);
				}
			}
			else if("searchDiv".equals(check)){
				int divid = Integer.parseInt(request.getParameter("divid"));
				if(divid == 0){
					userBeansList = tableUserDao.getStudentUserList(facid);
				}else{
					userBeansList = tableUserDao.getStudentUserList(facid,divid);
				}
			}
			else if("input_search".equals(check)){
				String inputText = request.getParameter("input");
				int divid = Integer.parseInt(request.getParameter("divid"));
				if(facid == 0 && divid == 0){
					userBeansList = tableUserDao.getStudentUserList(inputText);
				}else{
					userBeansList = tableUserDao.getStudentUserList(facid, divid, inputText);
				}
			}

			if(userBeansList.isEmpty()){
				out.print("null");
			}else{
				request.setAttribute("userList", userBeansList);
				doViewUserList(request, response);
			}
			return;
		}
		/* # search  */
		
		/* Update  */
		else if("update".equals(action)){
			int id = Integer.parseInt(request.getParameter("id"));
			String facid = request.getParameter("facid");
			String divid = request.getParameter("divid");
			StudentUserDao tableUserDao = new StudentUserDao();

			tableUserDao.updateFacAndDiv(id, facid, divid);
		}
		/* # Update  */
		
		/* Delete  */
		else if("Delete".equals(action)){
			int userid = Integer.parseInt(request.getParameter("id"));
			StudentDeleteUserDao studentDeleteUserDao = new StudentDeleteUserDao();
			
			if(studentDeleteUserDao.checkIdCoop03(userid)){
				int coop03id = studentDeleteUserDao.getIdCoop03(userid);
				String partPic = studentDeleteUserDao.getPictureCoop03(userid);
				FileUploadUtil.deleteProfilePic(request, partPic);
				studentDeleteUserDao.deleteCoop03(userid, coop03id);
			}
			
			if(studentDeleteUserDao.checkidCoop02(userid)){
				int coop02id = studentDeleteUserDao.getIdCoop02(userid);
				studentDeleteUserDao.deleteCoop02(userid, coop02id);
			}
			
			if(studentDeleteUserDao.checkIdProfile(userid)){
				int profileid = studentDeleteUserDao.getIdProfile(userid);
				studentDeleteUserDao.deleteProfile(userid, profileid);
			}
			
			//573333013017-1_6_coop02
			UserBean userBean = new UserBean();
			TableUserDao tableUserDao = new TableUserDao();
			userBean = tableUserDao.getTableUser(userid);
			String nameFile = userBean.getStudentid()+"_"+userid;
			FileUploadUtil.deleteReport(request, nameFile+"_coop02");
			FileUploadUtil.deleteReport(request, nameFile+"_coop03");
			studentDeleteUserDao.deleteUser(userid);
			//System.out.println("ok delete");
		}
		/* # Delete  */
		
		
		/* return total Number Student  */
		else if("sumAllStudent".equals(action)){
			// total count AllStudent return to number
			StudentUserDao tableUserDao = new StudentUserDao();
			int sumAllStudent = tableUserDao.getNumberStudent();
				//System.out.println(sumAllStudent);
			out.print(sumAllStudent);
			return;
		}
		else if("sumFacIDStudent".equals(action)){
			// total count FacStudent return to number
			StudentUserDao tableUserDao = new StudentUserDao();
			int facid = Integer.parseInt(request.getParameter("facid"));
			int sumFacStudent = tableUserDao.getNumberFacStudent(facid);
			if(sumFacStudent != 0){
				//System.out.println(sumFacStudent);
				out.print(sumFacStudent);
			}else{
				out.print("null");
			}
			return;
		}
		else if("sumFacAndDivStudent".equals(action)){
			// total count FacAndDivStudent return to number
			StudentUserDao tableUserDao = new StudentUserDao();
			int facid = Integer.parseInt(request.getParameter("facid"));
			int divid = Integer.parseInt(request.getParameter("divid"));
			int sumFacAndDivStudent = tableUserDao.getNumberFacAndDivStudent(facid, divid);
			//System.out.println(sumFacAndDivStudent);
			if(sumFacAndDivStudent != 0){
				out.print(sumFacAndDivStudent);
			}else{
				out.print("null");
			}
			return;
		}
		else if("sumInputSearchStudent".equals(action)){
			// total count Input Search Student return to number
			StudentUserDao tableUserDao = new StudentUserDao();
			int facid = Integer.parseInt(request.getParameter("facid"));
			int divid = Integer.parseInt(request.getParameter("divid"));
			String inputText =request.getParameter("inputText");
			//System.out.println("input == "+inputText);
			int sumInputSearchStudent = tableUserDao.getNumberInputSearchStudent(facid, divid, inputText);
			//System.out.println("total == "+sumInputSearchStudent);
			if(sumInputSearchStudent != 0){
				out.print(sumInputSearchStudent);
			}else{
				out.print("null");
			}
			return;
		}
		/* # return total Number Student  */
		
		/* return list student click pagination */
		else if("pageStudent".equals(action)){
			// check pageNumber  return  to total  list pageNumber
			int pageNum = Integer.parseInt(request.getParameter("pageNum"));
			String actionTypePage = request.getParameter("actionTypePage");
			ArrayList<UserBean> userListAll = new ArrayList<UserBean>();
			ArrayList<UserBean> userList = new ArrayList<UserBean>();
			StudentUserDao tableUserDao = new StudentUserDao();
			int facid = Integer.parseInt(request.getParameter("facid"));
			int divid = Integer.parseInt(request.getParameter("divid"));
			String inputText = request.getParameter("inputText");
			if("AllStudent".equals(actionTypePage)){
				// AllStudent
				userListAll = tableUserDao.getAllStudentUserList();
			}
			else if("FacStudent".equals(actionTypePage)){
				// FacStudent
				userListAll = tableUserDao.getAllFacStudentUserList(facid);
			}
			else if("DivStudent".equals(actionTypePage)){
				// DivStudent
				userListAll = tableUserDao.getAllFacAndDivStudentUserList(facid, divid);
			}
			else if("inputTextStudent".equals(actionTypePage)){
				// inputTextStudent
				userListAll = tableUserDao.getAllStudentUserList(facid, divid, inputText);
			}
			
			pageNum = pageNum - 1;
			pageNum = pageNum * 10; 
			// 1 table / 10 user
			//System.out.println(pageNum);
			
			for(int i=pageNum; i<=(pageNum+9); i++){
				if(i <= userListAll.size()-1){
					userList.add(userListAll.get(i));
				}
			}
			
			// cover  userListAll to userList
			request.setAttribute("userList", userList);
			request.setAttribute("count", pageNum);
			doViewUserList(request, response);
			return;
		}
		/* # return list student click pagination */


	}
	
	private void doViewStudentManagement(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/admin/student_management.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private void doViewUserList(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/user-list/userStudent-list.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}
}

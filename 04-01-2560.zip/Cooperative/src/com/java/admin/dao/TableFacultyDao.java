package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.admin.bean.FacultyBean;
import com.java.util.PreparedStatementUtil;

public class TableFacultyDao {
	public int addFaculty(FacultyBean facultyBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;
		int key = 0;
		try {
			String query = "INSERT INTO tb_faculty(Code,Name) VALUES(:code,:name)";
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setString("code", facultyBean.getCode());
			preparedStatementUtil.setString("name", facultyBean.getName());
			rs = preparedStatementUtil.executeInsertGetKeys();
			while (rs.next()) {
				key = rs.getInt(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return key;
	}

	public void editFaculty(FacultyBean facultyBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		try {
			String query = "UPDATE tb_faculty SET Code = :code,Name = :name Where ID = :id";
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setString("code", facultyBean.getCode());
			preparedStatementUtil.setString("name", facultyBean.getName());
			preparedStatementUtil.setInt("id", facultyBean.getId());
			preparedStatementUtil.execute();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	public void deleteFaculty(int facid){
		PreparedStatementUtil preparedStatementUtil = null;
		 // update = null   Faculty And Divsion Stuednt User
		DeleteUserDao deleteUserDao = new DeleteUserDao();
		deleteUserDao.updateDeleteFacultyUser(facid);
		
		// delete Division    Where  FacID = facid
		  try{
			   String query = "DELETE FROM tb_division WHERE FacID = :facid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("facid", facid);

			   preparedStatementUtil.execute();
			   
			  }catch(Exception e){
			   e.printStackTrace();
			  }finally{
			   if(preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			  }
		  
		  
		  //  Delete Faculty   Where id = facid
		  try{
			   String query = "DELETE FROM tb_faculty WHERE ID = :facid";
			   preparedStatementUtil = new PreparedStatementUtil(query);
			   preparedStatementUtil.setInt("facid", facid);
	
			   preparedStatementUtil.execute();
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
	
	public ArrayList<FacultyBean> getFacultyList(){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<FacultyBean> facultyBeanList = new ArrayList<FacultyBean>();
		
		String query = "SELECT ID,Code,Name FROM tb_faculty ORDER BY Code ASC ";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				FacultyBean facultyBean = new FacultyBean();
				facultyBean.setId(rs.getInt("ID"));
				facultyBean.setCode(rs.getString("Code"));
				facultyBean.setName(rs.getString("Name"));

				facultyBeanList.add(facultyBean);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return facultyBeanList;
	}
	
public FacultyBean getFacultyList(int id){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		FacultyBean facultyBean = new FacultyBean();
		
		String query = "SELECT ID,Code,Name FROM tb_faculty Where ID = :Facid";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("Facid", id);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				facultyBean.setId(rs.getInt("ID"));
				facultyBean.setCode(rs.getString("Code"));
				facultyBean.setName(rs.getString("Name"));
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return facultyBean;
	}

public Boolean getDeleteFaculty(int index){
	
	PreparedStatementUtil prepareStatementUtil = null;
	ResultSet rs = null;

	Boolean value = false;
	String query = "SELECT True as isDelete FROM tb_division where FacId = :FacID LIMIT 1";
	//String query = "CALL `sp_IsDelete_Division`(:FacID);";
	
	try {
		prepareStatementUtil = new PreparedStatementUtil(query);
		prepareStatementUtil.setInt("FacID", index);
		rs = prepareStatementUtil.executeQuery();
		
		if(rs.next()){
			value = rs.getBoolean("isDelete");
		}
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			prepareStatementUtil.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	return value;
}	
}

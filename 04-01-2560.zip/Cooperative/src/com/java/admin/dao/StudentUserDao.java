package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.student.bean.UserBean;
import com.java.util.PreparedStatementUtil;

public class StudentUserDao {
	
	public int  getNumberStudent(){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		int count = 0;
		String query = "SELECT COUNT(*) AS NumberStudent FROM tb_user WHERE tb_user.RoleID = 1 ";

		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				count = rs.getInt("NumberStudent");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return count;
	}
	

	public ArrayList<UserBean> getAllStudentUserList(){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		
		String query = "SELECT tb_user.ID,"
				+ "tb_user.StudentID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_faculty.Name AS facultyName,"
				+ "tb_division.Name AS divisionName,"
				+ "tb_user.FacID,"
				+ "tb_user.DivID "
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
				+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
				+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
				+ " WHERE tb_user.RoleID = 1 ";
	
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setFacid(rs.getInt("FacID"));
				userBean.setDivid(rs.getInt("DivID"));
				userBeanList.add(userBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userBeanList;
	}
	
	
	public ArrayList<UserBean> getStudentUserList(){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		
		String query = "SELECT tb_user.ID,"
				+ "tb_user.StudentID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_faculty.Name AS facultyName,"
				+ "tb_division.Name AS divisionName,"
				+ "tb_user.FacID,"
				+ "tb_user.DivID "
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
				+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
				+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
				+ " WHERE tb_user.RoleID = 1 LIMIT 10 ";
	
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setFacid(rs.getInt("FacID"));
				userBean.setDivid(rs.getInt("DivID"));
				userBeanList.add(userBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userBeanList;
	}
  /*  # list student */

	
	
	
	public int  getNumberFacStudent(int facid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		int count = 0;
		String query = "SELECT COUNT(*) AS NumberFacStudent FROM tb_user WHERE tb_user.RoleID = 1 && tb_user.FacID = :facid";

		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("facid", facid);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				count = rs.getInt("NumberFacStudent");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return count;
	}
	
	public int  getNumberFacAndDivStudent(int facid,int divid){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		int count = 0;
		String query = "";

		try {
			if(divid == 0){
				// get all student  div = 0
				query = "SELECT COUNT(*) AS NumberFacAndDivStudent FROM tb_user WHERE tb_user.RoleID = 1 "
						+ " && tb_user.FacID = :facid ";
				prepareStatementUtil = new PreparedStatementUtil(query);
				prepareStatementUtil.setInt("facid", facid);
			}else{
				query = "SELECT COUNT(*) AS NumberFacAndDivStudent FROM tb_user WHERE tb_user.RoleID = 1 "
						+ " && tb_user.FacID = :facid "
						+ " && tb_user.DivID = :divid";
				prepareStatementUtil = new PreparedStatementUtil(query);
				prepareStatementUtil.setInt("facid", facid);
				prepareStatementUtil.setInt("divid", divid);
			}

			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				count = rs.getInt("NumberFacAndDivStudent");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return count;
	}

	public int  getNumberInputSearchStudent(int facid,int divid,String searchStudentID){
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		int count = 0;
		String query = "";

		try {
			if(facid == 0 && divid == 0){
				query = "SELECT COUNT(*) AS NumberInputSearchStudent FROM tb_user WHERE tb_user.RoleID = 1 "
						+ " && tb_user.StudentID LIKE '%"+searchStudentID+"%'";
				prepareStatementUtil = new PreparedStatementUtil(query);
			}
			else if(facid != 0 && divid == 0){
				query = "SELECT COUNT(*) AS NumberInputSearchStudent FROM tb_user WHERE tb_user.RoleID = 1 "
						+ " && tb_user.FacID = :facid "
						+ " && tb_user.StudentID LIKE '%"+searchStudentID+"%'";
				prepareStatementUtil = new PreparedStatementUtil(query);
				prepareStatementUtil.setInt("facid", facid);
			}
			else{
				query = "SELECT COUNT(*) AS NumberInputSearchStudent FROM tb_user WHERE tb_user.RoleID = 1 "
						+ " && tb_user.FacID = :facid "
						+ " && tb_user.DivID = :divid "
						+ " && tb_user.StudentID LIKE '%"+searchStudentID+"%'";
				prepareStatementUtil = new PreparedStatementUtil(query);
				prepareStatementUtil.setInt("facid", facid);
				prepareStatementUtil.setInt("divid", divid);
			}
			
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				count = rs.getInt("NumberInputSearchStudent");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return count;
	}

	
	
	public ArrayList<UserBean> getAllFacStudentUserList(int facid){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		
		String query = "SELECT tb_user.ID,"
				+ "tb_user.StudentID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_faculty.Name AS facultyName,"
				+ "tb_division.Name AS divisionName,"
				+ "tb_user.FacID,"
				+ "tb_user.DivID "
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
				+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
				+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
				+ " WHERE tb_user.FacID = :id && tb_user.RoleID = 1 ";
	
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("id", facid);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setFacid(rs.getInt("FacID"));
				userBean.setDivid(rs.getInt("DivID"));
				userBeanList.add(userBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userBeanList;
	}	
	
	public ArrayList<UserBean> getStudentUserList(int facid){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		
		String query = "SELECT tb_user.ID,"
				+ "tb_user.StudentID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_faculty.Name AS facultyName,"
				+ "tb_division.Name AS divisionName,"
				+ "tb_user.FacID,"
				+ "tb_user.DivID "
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
				+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
				+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
				+ " WHERE tb_user.FacID = :id && tb_user.RoleID = 1 LIMIT 10 ";
	
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("id", facid);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setFacid(rs.getInt("FacID"));
				userBean.setDivid(rs.getInt("DivID"));
				userBeanList.add(userBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userBeanList;
	}	

	public ArrayList<UserBean> getAllFacAndDivStudentUserList(int facid, int divid){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		
		String query = "SELECT tb_user.ID,"
				+ "tb_user.StudentID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_faculty.Name AS facultyName,"
				+ "tb_division.Name AS divisionName,"
				+ "tb_user.FacID,"
				+ "tb_user.DivID "
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
				+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
				+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
				+ " WHERE tb_user.FacID = :facid && tb_user.DivID = :divid && tb_user.RoleID = 1 ";
	
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("facid", facid);
			prepareStatementUtil.setInt("divid", divid);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setFacid(rs.getInt("FacID"));
				userBean.setDivid(rs.getInt("DivID"));
				userBeanList.add(userBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userBeanList;
	}		
	
	public ArrayList<UserBean> getStudentUserList(int facid, int divid){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		
		String query = "SELECT tb_user.ID,"
				+ "tb_user.StudentID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_faculty.Name AS facultyName,"
				+ "tb_division.Name AS divisionName,"
				+ "tb_user.FacID,"
				+ "tb_user.DivID "
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
				+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
				+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
				+ " WHERE tb_user.FacID = :facid && tb_user.DivID = :divid && tb_user.RoleID = 1 LIMIT 10 ";
	
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("facid", facid);
			prepareStatementUtil.setInt("divid", divid);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setFacid(rs.getInt("FacID"));
				userBean.setDivid(rs.getInt("DivID"));
				userBeanList.add(userBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userBeanList;
	}	

	public ArrayList<UserBean> getAllStudentUserList(String searchStudentID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		
		String query = "SELECT tb_user.ID,"
				+ "tb_user.StudentID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_faculty.Name AS facultyName,"
				+ "tb_division.Name AS divisionName,"
				+ "tb_user.FacID,"
				+ "tb_user.DivID "
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
				+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
				+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
				+ " WHERE tb_user.RoleID = 1 && "
				+ " tb_user.StudentID LIKE '%"+searchStudentID+"%'";
	
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setFacid(rs.getInt("FacID"));
				userBean.setDivid(rs.getInt("DivID"));
				userBeanList.add(userBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userBeanList;
	}
	
	public ArrayList<UserBean> getStudentUserList(String searchStudentID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		
		String query = "SELECT tb_user.ID,"
				+ "tb_user.StudentID,"
				+ "tb_title.Name_th AS TitleName,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_faculty.Name AS facultyName,"
				+ "tb_division.Name AS divisionName,"
				+ "tb_user.FacID,"
				+ "tb_user.DivID "
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
				+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
				+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
				+ " WHERE tb_user.RoleID = 1 && "
				+ " tb_user.StudentID LIKE '%"+searchStudentID+"%' LIMIT 10 ";
	
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setFacid(rs.getInt("FacID"));
				userBean.setDivid(rs.getInt("DivID"));
				userBeanList.add(userBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userBeanList;
	}
	

	public ArrayList<UserBean> getAllStudentUserList(int facid,int divid ,String search){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		String query = "";

		try {
			
			if(facid == 0 && divid == 0){
				 query = "SELECT tb_user.ID,"
							+ "tb_user.StudentID,"
							+ "tb_title.Name_th AS TitleName,"
							+ "tb_user.FirstName_th,"
							+ "tb_user.LastName_th,"
							+ "tb_faculty.Name AS facultyName,"
							+ "tb_division.Name AS divisionName,"
							+ "tb_user.FacID,"
							+ "tb_user.DivID "
							+ " FROM tb_user "
							+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
							+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
							+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
							+ " WHERE tb_user.StudentID LIKE '%"+search+"%' && tb_user.RoleID = 1 ";
				 prepareStatementUtil = new PreparedStatementUtil(query);
			}
			else if(facid != 0 && divid == 0){
				 query = "SELECT tb_user.ID,"
							+ "tb_user.StudentID,"
							+ "tb_title.Name_th AS TitleName,"
							+ "tb_user.FirstName_th,"
							+ "tb_user.LastName_th,"
							+ "tb_faculty.Name AS facultyName,"
							+ "tb_division.Name AS divisionName,"
							+ "tb_user.FacID,"
							+ "tb_user.DivID "
							+ " FROM tb_user "
							+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
							+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
							+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
							+ " WHERE tb_user.FacID = :facid  && tb_user.RoleID = 1"
							+ " && tb_user.StudentID LIKE '%"+search+"%'";
				 prepareStatementUtil = new PreparedStatementUtil(query);
				 prepareStatementUtil.setInt("facid", facid);
			}
			else{
				 query = "SELECT tb_user.ID,"
							+ "tb_user.StudentID,"
							+ "tb_title.Name_th AS TitleName,"
							+ "tb_user.FirstName_th,"
							+ "tb_user.LastName_th,"
							+ "tb_faculty.Name AS facultyName,"
							+ "tb_division.Name AS divisionName,"
							+ "tb_user.FacID,"
							+ "tb_user.DivID "
							+ " FROM tb_user "
							+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
							+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
							+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
							+ " WHERE tb_user.FacID = :facid  && tb_user.DivID = :divid && tb_user.RoleID = 1"
							+ " && tb_user.StudentID LIKE '%"+search+"%'";
				 prepareStatementUtil = new PreparedStatementUtil(query);
				 prepareStatementUtil.setInt("facid", facid);
				 prepareStatementUtil.setInt("divid", divid);
			}
			
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setFacid(rs.getInt("FacID"));
				userBean.setDivid(rs.getInt("DivID"));
				userBeanList.add(userBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userBeanList;
	}	
	
	public ArrayList<UserBean> getStudentUserList(int facid,int divid ,String search){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		String query = "";
		
		if(divid == 0){
			 query = "SELECT tb_user.ID,"
						+ "tb_user.StudentID,"
						+ "tb_title.Name_th AS TitleName,"
						+ "tb_user.FirstName_th,"
						+ "tb_user.LastName_th,"
						+ "tb_faculty.Name AS facultyName,"
						+ "tb_division.Name AS divisionName,"
						+ "tb_user.FacID,"
						+ "tb_user.DivID "
						+ " FROM tb_user "
						+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
						+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
						+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
						+ " WHERE tb_user.FacID = :facid  && tb_user.RoleID = 1 &&"
						+ " tb_user.StudentID LIKE '%"+search+"%' LIMIT 10 ";
		}else{
			 query = "SELECT tb_user.ID,"
					+ "tb_user.StudentID,"
					+ "tb_title.Name_th AS TitleName,"
					+ "tb_user.FirstName_th,"
					+ "tb_user.LastName_th,"
					+ "tb_faculty.Name AS facultyName,"
					+ "tb_division.Name AS divisionName,"
					+ "tb_user.FacID,"
					+ "tb_user.DivID "
					+ " FROM tb_user "
					+ " LEFT JOIN tb_title on tb_title.ID = tb_user.TitleID "
					+ " LEFT JOIN tb_faculty on tb_faculty.ID = tb_user.FacID "
					+ " LEFT JOIN tb_division on tb_division.ID = tb_user.DivID "
					+ " WHERE tb_user.FacID = :facid  && "
					+ " tb_user.DivID = :divid && "
					+ " tb_user.StudentID LIKE '%"+search+"%' LIMIT 10 ";
		}
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("facid", facid);
			if(divid != 0){
				prepareStatementUtil.setInt("divid", divid);
			}

			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("ID"));
				userBean.setStudentid(rs.getString("StudentID"));
				userBean.setTitlename_th(rs.getString("TitleName"));
				userBean.setFirstname_th(rs.getString("FirstName_th"));
				userBean.setLastname_th(rs.getString("LastName_th"));
				userBean.setFacname(rs.getString("facultyName"));
				userBean.setDivname(rs.getString("divisionName"));
				userBean.setFacid(rs.getInt("FacID"));
				userBean.setDivid(rs.getInt("DivID"));
				userBeanList.add(userBean);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return userBeanList;
	}
	
	
	public void updateFacAndDiv(int id, String facid, String divid){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_user SET "
		   				+ "FacID = :facID,"
		   				+ "DivID = :divID " 
		   				+ "WHERE tb_user.ID = :id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("facID", facid);
		   preparedStatementUtil.setString("divID", divid);
		   preparedStatementUtil.setInt("id", id);
		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
}

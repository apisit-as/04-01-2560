package com.java.admin.dao;

import java.sql.SQLException;

import com.java.util.PreparedStatementUtil;

public class DeleteUserDao {
	
	// all role
	public void updateDeleteDivsionUser(int divsionid){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_user SET "
		   				+ "DivID = null " 
		   				+ "WHERE tb_user.DivID = :divsionid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setInt("divsionid", divsionid);

		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
	
	
	
	// all role
	public void updateDeleteFacultyUser(int facid){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_user SET "
				   		+ "FacID = null ,"
		   				+ "DivID = null " 
		   				+ "WHERE tb_user.FacID = :facid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setInt("facid", facid);

		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
}

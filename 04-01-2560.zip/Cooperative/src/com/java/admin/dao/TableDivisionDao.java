package com.java.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.java.admin.bean.DivisionBean;
import com.java.util.PreparedStatementUtil;

public class TableDivisionDao {
	public void editDivision(DivisionBean dvisionBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		try {
			String query = "UPDATE tb_division SET "
						+ " Code = :code,"
						+ " Name = :name,"
						+ " Initials = :initials "
						+ " Where ID = :id";
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setString("code", dvisionBean.getCode());
			preparedStatementUtil.setString("name", dvisionBean.getName());
			preparedStatementUtil.setString("initials", dvisionBean.getInitials());
			preparedStatementUtil.setInt("id", dvisionBean.getId());
			preparedStatementUtil.execute();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (preparedStatementUtil != null)
				try {
					preparedStatementUtil.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	public void deleteDvision(int divid){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		 // update = null   Divsion Stuednt User
		 DeleteUserDao deleteUserDao = new DeleteUserDao();
		 deleteUserDao.updateDeleteDivsionUser(divid);
		
		 // Delete Division
		  try{
		   String query = "DELETE FROM tb_division WHERE ID = :id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   preparedStatementUtil.setInt("id", divid);

		   preparedStatementUtil.execute();
		   
		  }catch(Exception e){
			 System.out.println("ERROR FK");
		     e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
	

	public void addDivision(DivisionBean divisionBean) {
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "INSERT INTO tb_division(Code,Name,Initials,FacID) VALUES(:code,:name,:initials,:facid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("code", divisionBean.getCode());
		   preparedStatementUtil.setString("name", divisionBean.getName());
		   preparedStatementUtil.setString("initials", divisionBean.getInitials());
		   preparedStatementUtil.setInt("facid", divisionBean.getFacid());


		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
	
	
	
	public ArrayList<DivisionBean> getDivisionList(int facid){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
		ArrayList<DivisionBean> divisionList = new ArrayList<DivisionBean>();
		
		String query = "SELECT ID,Code,Name,Initials,FacID FROM tb_division "
				+ " WHERE tb_division.FacID = :facid "
				+ " ORDER BY tb_division.Code ASC ";

		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("facid", facid);
			rs = prepareStatementUtil.executeQuery();
			
			while(rs.next()){
				DivisionBean divisionBean = new DivisionBean();
				divisionBean.setId(rs.getInt("ID"));
				divisionBean.setCode(rs.getString("Code"));
				divisionBean.setName(rs.getString("Name"));
				divisionBean.setInitials(rs.getString("Initials"));
				divisionBean.setFacid(rs.getInt("FacID"));
				divisionList.add(divisionBean);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return divisionList;
	}
	
	public DivisionBean retrieveDivision(int id){   
		
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		DivisionBean divisionBean = new DivisionBean();
		
		String query = "SELECT ID,Code,Name,Initials FROM tb_division"
				+ " WHERE ID = "+id;  
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				divisionBean.setId(rs.getInt("ID"));
				divisionBean.setCode(rs.getString("Code"));
				divisionBean.setName(rs.getString("Name"));
				divisionBean.setInitials(rs.getString("Initials"));
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return divisionBean;
	}
}

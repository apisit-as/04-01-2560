package com.java.db;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBConnection {
	public static Connection getConnection(){
		
		Connection connection = null;
		Context context = null;
		String jdbc = "java:comp/env/jdbc/mysql";
		
		try{
			context = new InitialContext();
			DataSource ds = (DataSource) context.lookup(jdbc);
			connection = ds.getConnection();
		}catch(NamingException namingException){
			connection = null;
			namingException.printStackTrace();
		}catch(SQLException sqlException){
			connection = null;
			sqlException.printStackTrace();
		}
		
		return connection;
	}
}

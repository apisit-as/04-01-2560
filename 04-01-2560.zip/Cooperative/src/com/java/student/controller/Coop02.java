package com.java.student.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.DATA_CONVERSION;

import com.java.student.bean.AddressBean;
import com.java.student.bean.Coop02Bean;

import com.java.student.bean.FamilyBean;
import com.java.student.bean.Language02Bean;
import com.java.student.bean.ProfileBean;
import com.java.student.bean.SelectJob02Bean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableAddressDao;
import com.java.student.dao.TableCoop02Dao;

import com.java.student.dao.TableFamilyDao;
import com.java.student.dao.TableLanguage02Dao;
import com.java.student.dao.TableProfileDao;
import com.java.student.dao.TableSelectJob02Dao;
import com.java.student.dao.TableUserDao;
import com.java.util.report.ReportCoop02;

/**
 * Servlet implementation class Coop02
 */
@WebServlet("/Coop02")
public class Coop02 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Coop02() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		
		HttpSession session = request.getSession();
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();

		String role = session.getAttribute("role").toString();
		if(role.equals("1")){
			// student
			// get db   name ...
			String UserID = session.getAttribute("UserID").toString();
			userBean = tableUserDao.getTableUser(Integer.parseInt(UserID));
			request.setAttribute("userBean", userBean);
			session.setAttribute("divID", userBean.getDivid());
			session.setAttribute("divName", userBean.getDivname());
			

			// select  profile dao
			ProfileBean ListProfileBean = new ProfileBean();
			TableProfileDao tableProfileDao = new TableProfileDao();
			ListProfileBean = tableProfileDao.SelectProfile(Integer.parseInt(UserID));
			request.setAttribute("ListProfileBean", ListProfileBean);
			
			// checkUserid  tb_profile
			boolean checkUserid = tableProfileDao.CheckProfile(Integer.parseInt(UserID));
			request.setAttribute("checkUserid", checkUserid);
			
			
			// select address type
			TableProfileDao checkKeyProfile = new TableProfileDao();
			int keyProfile = checkKeyProfile.getKeyIDProfile(Integer.parseInt(UserID));
			

			TableAddressDao addressDao = new TableAddressDao();
			AddressBean original_address = new AddressBean();
			original_address = addressDao.SelectAddressType(keyProfile, "original_address");
			
			AddressBean semester_address = new AddressBean();
			semester_address = addressDao.SelectAddressType(keyProfile, "semester_address");
			
			AddressBean parent_address = new AddressBean();
			parent_address = addressDao.SelectAddressType(keyProfile, "parent_address");
			
			request.setAttribute("original_address", original_address);
			request.setAttribute("semester_address", semester_address);
			request.setAttribute("parent_address", parent_address);

			session.setAttribute("amphur_original_address_id", original_address.getAmphurid());
			session.setAttribute("amphur_original_address_name", original_address.getAmphurname());
			session.setAttribute("district_original_address_id", original_address.getDistrictid());
			session.setAttribute("district_original_address_name", original_address.getDistrictname());
			
			session.setAttribute("amphur_semester_address_id", semester_address.getAmphurid());
			session.setAttribute("amphur_semester_address_name", semester_address.getAmphurname());
			session.setAttribute("district_semester_address_id", semester_address.getDistrictid());
			session.setAttribute("district_semester_address_name", semester_address.getDistrictname());

			session.setAttribute("amphur_parent_address_id", parent_address.getAmphurid());
			session.setAttribute("amphur_parent_address_name", parent_address.getAmphurname());
			session.setAttribute("district_parent_address_id", parent_address.getDistrictid());
			session.setAttribute("district_parent_address_name", parent_address.getDistrictname());

			// family
			FamilyBean parent_family = new FamilyBean();
			TableFamilyDao tableFamilyDao = new TableFamilyDao();
			parent_family = tableFamilyDao.SelectFamilyType(keyProfile, "parent_family");
			request.setAttribute("parent_family", parent_family);
			
			// coop02 detail
			Coop02Bean coop02Bean = new Coop02Bean();
			SelectJob02Bean selectJob02Bean = new SelectJob02Bean();
			Language02Bean language02Bean = new Language02Bean();
			TableCoop02Dao tableCoop02Dao = new TableCoop02Dao();
			TableSelectJob02Dao tableSelectJob02Dao = new TableSelectJob02Dao();
			TableLanguage02Dao tableLanguage02Dao = new TableLanguage02Dao();
			
			coop02Bean = tableCoop02Dao.SelectCoop02(Integer.parseInt(UserID));
			int Coop02ID = tableCoop02Dao.getKeyIDCoop02(Integer.parseInt(UserID));
			
			selectJob02Bean = tableSelectJob02Dao.SelectJob02(Coop02ID);
			language02Bean = tableLanguage02Dao.SelectLanguage02(Coop02ID);
		
			request.setAttribute("coop02Bean", coop02Bean);
			request.setAttribute("selectJob02Bean", selectJob02Bean);
			request.setAttribute("language02Bean", language02Bean);
			
			
			doViewCoop02(request, response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		String UserID = session.getAttribute("UserID").toString();

		TableCoop02Dao tableCoop02Dao = new TableCoop02Dao();
		TableSelectJob02Dao tableSelectJob02Dao = new TableSelectJob02Dao();
		TableLanguage02Dao tableLanguage02Dao = new TableLanguage02Dao();
		Coop02Bean coop02Bean = new Coop02Bean();
		SelectJob02Bean selectJob02Bean = new SelectJob02Bean();
		Language02Bean language02Bean = new Language02Bean();
	
		coop02Bean.setTalent(request.getParameter("Talent").toString());
		language02Bean.setLanguage_eng(request.getParameter("LanguageID_eng").toString());
		language02Bean.setLeve_eng(request.getParameter("level_eng").toString());
		language02Bean.setLanguage_jap(request.getParameter("LanguageID_jp").toString());
		language02Bean.setLeve_jap(request.getParameter("level_jp").toString());
		language02Bean.setLanguage_chi(request.getParameter("LanguageID_ca").toString());
		language02Bean.setLeve_chi(request.getParameter("level_ca").toString());
		language02Bean.setLanguage_other(request.getParameter("LanguageID_other").toString());
		language02Bean.setOther(request.getParameter("input_other").toString());
		language02Bean.setLeve_other(request.getParameter("level_other").toString());
		coop02Bean.setRegion(request.getParameter("region").toString());
		selectJob02Bean.setJob(request.getParameter("SelectJob").toString());
		selectJob02Bean.setOther(request.getParameter("Other").toString());
		coop02Bean.setInterest(request.getParameter("Interest").toString());
		coop02Bean.setTerm(request.getParameter("Semester").toString());
		coop02Bean.setAcademic_year(request.getParameter("Academic_year").toString());
		
	
		String action = request.getParameter("action");
		if("input".equals(action)){
			
			if(tableCoop02Dao.CheckCoop02(Integer.parseInt(UserID))){
				// update
				System.out.println("Update");
				coop02Bean.setUserid(Integer.parseInt(UserID));
				tableCoop02Dao.UpdateCoop02(coop02Bean);
				int key = tableCoop02Dao.getKeyIDCoop02(Integer.parseInt(UserID));
				selectJob02Bean.setCoop02id(key);
				tableSelectJob02Dao.UpdateSelectJob02(selectJob02Bean);
				language02Bean.setCoop02id(key);
				tableLanguage02Dao.UpdateLanguage02(language02Bean);
			}else{
				// insert
				System.out.println("Insert");
				coop02Bean.setUserid(Integer.parseInt(UserID));
				tableCoop02Dao.InsertCoop02(coop02Bean);
				int key = tableCoop02Dao.getKeyIDCoop02(Integer.parseInt(UserID));
				selectJob02Bean.setCoop02id(key);
				tableSelectJob02Dao.InsertSelectJob02(selectJob02Bean);
				language02Bean.setCoop02id(key);
				tableLanguage02Dao.InsertLanguage02(language02Bean);
			}

			/* report */
			int userid = Integer.parseInt(UserID);
			reportCoop02(request, userid);
			/* report */
		}
		
	}

	private void doViewCoop02(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/coop02.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	private void reportCoop02(HttpServletRequest request,int userid) {
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();
		userBean = tableUserDao.getTableUser(userid);
		
		TableProfileDao tableProfileDao = new TableProfileDao();
		ProfileBean profileBean = new ProfileBean();
		TableAddressDao tableAddressDao = new TableAddressDao();
		AddressBean addressBean1 = new AddressBean();
		AddressBean addressBean2 = new AddressBean();
		AddressBean addressBean3 = new AddressBean();
		TableFamilyDao tableFamilyDao = new TableFamilyDao();
		FamilyBean familyBean = new FamilyBean();
		
		// tb_profile, tb_address  , tb_family >>tye  parent_family
		profileBean = tableProfileDao.SelectProfile(userid);
		addressBean1 = tableAddressDao.SelectAddressType(profileBean.getId(), "original_address");
		addressBean1.setAmphurname(subString(addressBean1.getAmphurname()));
		addressBean1.setDistrictname(subString(addressBean1.getDistrictname()));

		addressBean2 = tableAddressDao.SelectAddressType(profileBean.getId(), "semester_address");
		addressBean2.setAmphurname(subString(addressBean2.getAmphurname()));
		addressBean2.setDistrictname(subString(addressBean2.getDistrictname()));
		
		addressBean3 = tableAddressDao.SelectAddressType(profileBean.getId(), "parent_address");
		addressBean3.setAmphurname(subString(addressBean3.getAmphurname()));
		addressBean3.setDistrictname(subString(addressBean3.getDistrictname()));
		
		familyBean = tableFamilyDao.SelectFamilyType(profileBean.getId(), "parent_family");
		
		
		TableCoop02Dao tableCoop02Dao2 = new TableCoop02Dao();
		TableSelectJob02Dao tableSelectJob02Dao2 = new TableSelectJob02Dao();
		TableLanguage02Dao tableLanguage02Dao2 = new TableLanguage02Dao();
		Coop02Bean coop02Bean2 = new Coop02Bean();
		SelectJob02Bean selectJob02Bean2 = new SelectJob02Bean();
		Language02Bean language02Bean2 = new Language02Bean();
		
		// coop02, select, language
		coop02Bean2 = tableCoop02Dao2.SelectCoop02(userid);
		selectJob02Bean2 = tableSelectJob02Dao2.SelectJob02(coop02Bean2.getId());
		language02Bean2 = tableLanguage02Dao2.SelectLanguage02(coop02Bean2.getId());
		
		// date
	      Date date = new Date( );
	      SimpleDateFormat ft =  new SimpleDateFormat ("dd.MM.yyyy");
	      String dateText = ft.format(date);
	      String[] dateSplit = dateText.split("[.]");
	      String [] dateMonthNumCheck = {"01","02","03","04","05","06","07","08","09","10","11","12"};
	      String [] dateMonthStrCheck = {"�.�.","�.�.","��.�.","��.�.","�.�.","��.�.","�.�.","�.�.","�.�.","�.�.","�.�.","�.�."};
	      
	      String date_day = dateSplit[0];
	      for(int i=0; i<=8; i++){
	    	  if(dateMonthNumCheck[i].equals(date_day)){
	    		  date_day = Integer.toString(i+1);
	    	  }
	      }
	      
	      String date_month = dateSplit[1];
	      for(int i=0; i<12; i++){
	    	  if(dateMonthNumCheck[i].equals(date_month)){
	    		  date_month = dateMonthStrCheck[i];
	    	  }
	      }

	      String date_year = dateSplit[2];
	      
		
		// save report  pdf,docx 
		ReportCoop02 reportCoop02 = new ReportCoop02();
		reportCoop02.insertCoop02Pdf(request,userBean,profileBean,addressBean1,addressBean2,addressBean3,familyBean,coop02Bean2,selectJob02Bean2,language02Bean2,date_day,date_month,date_year);
		//reportCoop02.insertCoop02Docx(request,userBean,profileBean,addressBean1,addressBean2,addressBean3,familyBean,coop02Bean2,selectJob02Bean2,language02Bean2);
		
	}
	
	private String subString(String textData){
		String text = textData.trim();
		int count = 0;
		String data = "";
		String sub = ""+text.charAt(0);
	      if("*".equals(sub)){
	    	  //System.out.println(text.substring(1));
	    	  data = ""+text.substring(1);
	    	  count++;
	      }
	      
	      sub = ""+text.charAt(text.length()-1);
	      if("*".equals(sub)){
	    	  //System.out.println(text.substring(0,text.length()-1));
	    	  data = ""+text.substring(0,text.length()-1);
	    	  count++;
	      }
	      
	      if(count == 0){
	    	  data = ""+text;
	    	 // System.out.println(data);
	      }
		return data;
	}
}

package com.java.student.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.list.bean.AmphurBean;
import com.java.list.bean.DistrictBean;
import com.java.list.bean.DivisionBean;
import com.java.list.bean.FacltyBean;
import com.java.list.bean.ProvinceBean;
import com.java.list.dao.AmphurSelectListDao;
import com.java.list.dao.DistrictSelectListDao;
import com.java.list.dao.DivisionSelectListDao;
import com.java.list.dao.FacultySelectListDao;
import com.java.list.dao.ProvinceSelectListDao;
import com.java.student.bean.ActivityBean;
import com.java.student.bean.AddressBean;
import com.java.student.bean.CareerBean;
import com.java.student.bean.Coop02Bean;
import com.java.student.bean.Coop03Bean;
import com.java.student.bean.EducationBean;
import com.java.student.bean.FamilyBean;
import com.java.student.bean.Language02Bean;
import com.java.student.bean.Language03Bean;
import com.java.student.bean.ProfileBean;
import com.java.student.bean.RelativeBean;
import com.java.student.bean.SelectJob02Bean;
import com.java.student.bean.TrainingBean;
import com.java.student.bean.UserBean;
import com.java.student.dao.TableActivityDao;
import com.java.student.dao.TableAddressDao;
import com.java.student.dao.TableCareerDao;
import com.java.student.dao.TableCoop02Dao;
import com.java.student.dao.TableCoop03Dao;
import com.java.student.dao.TableEducationDao;
import com.java.student.dao.TableFamilyDao;
import com.java.student.dao.TableLanguage02Dao;
import com.java.student.dao.TableLanguage03Dao;
import com.java.student.dao.TableProfileDao;
import com.java.student.dao.TableRelativeDao;
import com.java.student.dao.TableSelectJob02Dao;
import com.java.student.dao.TableTrainingDao;
import com.java.student.dao.TableUserDao;
import com.java.util.report.ReportCoop02;
import com.java.util.report.ReportCoop03;




/**
 * Servlet implementation class DataStudent
 */
@WebServlet("/DataStudent")
public class DataStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DataStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		  response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
		  response.addHeader("Cache-Control", "post-check=0, pre-check=0");
		  response.setHeader("Pragma", "no-cache");
		  response.setDateHeader("Expires", 0);
		
		HttpSession session = request.getSession();
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();

		String role = session.getAttribute("role").toString();
		if(role.equals("1")){
			// student
			// get db   name ...
			String UserID = session.getAttribute("UserID").toString();
			userBean = tableUserDao.getTableUser(Integer.parseInt(UserID));
			request.setAttribute("userBean", userBean);
			session.setAttribute("divID", userBean.getDivid());
			session.setAttribute("divName", userBean.getDivname());
			
			// select list Faclty
			ArrayList<FacltyBean> listFaclty = new ArrayList<FacltyBean>();
			FacultySelectListDao facultySelectListDao = new FacultySelectListDao();			
			listFaclty = facultySelectListDao.getFacltyList();
			request.setAttribute("listFaclty", listFaclty);

			// select list Division
 			DivisionSelectListDao divisionSelectListDao = new DivisionSelectListDao();
			ArrayList<DivisionBean> listDivision = new ArrayList<DivisionBean>();
			listDivision = divisionSelectListDao.getDivisionList((userBean.getFacid()));
			request.setAttribute("listDivision", listDivision);
			
			
			// select  profile dao
			ProfileBean ListProfileBean = new ProfileBean();
			TableProfileDao tableProfileDao = new TableProfileDao();
			
			if(tableProfileDao.CheckProfile(Integer.parseInt(UserID))){
				
				ListProfileBean = tableProfileDao.SelectProfile(Integer.parseInt(UserID));
				
				// ListProfileBean
				String[] str1 = ListProfileBean.getIssue_date().split("-");    //2016-11-20
				String[] str2 = ListProfileBean.getExpiry_date().split("-");
				String[] str3 = ListProfileBean.getBirthday().split("-");
				ListProfileBean.setIssue_date(str1[2]+"/"+str1[1]+"/"+(Integer.parseInt(str1[0])+543));
				ListProfileBean.setExpiry_date(str2[2]+"/"+str2[1]+"/"+(Integer.parseInt(str2[0])+543));
				ListProfileBean.setBirthday(str3[2]+"/"+str3[1]+"/"+(Integer.parseInt(str3[0])+543));
				request.setAttribute("EditProfile", "false");
			}else{
				request.setAttribute("EditProfile", "true");
			}

			request.setAttribute("ListProfileBean", ListProfileBean);

			
			// select address type
			TableProfileDao checkKeyProfile = new TableProfileDao();
			int keyProfile = checkKeyProfile.getKeyIDProfile(Integer.parseInt(UserID));
			
			TableAddressDao addressDao = new TableAddressDao();
			AddressBean original_address = new AddressBean();
			original_address = addressDao.SelectAddressType(keyProfile, "original_address");
			
			AddressBean semester_address = new AddressBean();
			semester_address = addressDao.SelectAddressType(keyProfile, "semester_address");
			
			AddressBean parent_address = new AddressBean();
			parent_address = addressDao.SelectAddressType(keyProfile, "parent_address");
			
			request.setAttribute("original_address", original_address);
			request.setAttribute("semester_address", semester_address);
			request.setAttribute("parent_address", parent_address);

			// select address province  amphur   district
			// original
			{
			ArrayList<ProvinceBean> original_provinceList = new ArrayList<ProvinceBean>(); 
			ProvinceSelectListDao original_provinceSelectListDao = new ProvinceSelectListDao();
			original_provinceList = original_provinceSelectListDao.getProvinceList();
			
			ArrayList<AmphurBean> original_amphurList = new ArrayList<AmphurBean>(); 
			AmphurSelectListDao original_amphurSelectListDao = new AmphurSelectListDao();
			original_amphurList = original_amphurSelectListDao.getAmphurList(original_address.getProvinceid());
			
			ArrayList<DistrictBean> original_districtList = new ArrayList<DistrictBean>(); 
			DistrictSelectListDao original_districtSelectListDao = new DistrictSelectListDao();
			original_districtList = original_districtSelectListDao.getDistrictList(original_address.getAmphurid());
			
			request.setAttribute("listProvince_original_address", original_provinceList);
			request.setAttribute("listAmphur_original_address", original_amphurList);
			request.setAttribute("listDistrict_original_address", original_districtList);
			
			session.setAttribute("amphur_original_address_id", original_address.getAmphurid());
			session.setAttribute("amphur_original_address_name", original_address.getAmphurname());
			session.setAttribute("district_original_address_id", original_address.getDistrictid());
			session.setAttribute("district_original_address_name", original_address.getDistrictname());
			}
			//  # original
			

			// semester_address
			{
			ArrayList<ProvinceBean> semester_provinceList = new ArrayList<ProvinceBean>(); 
			ProvinceSelectListDao semester_provinceSelectListDao = new ProvinceSelectListDao();
			semester_provinceList = semester_provinceSelectListDao.getProvinceList();
			
			ArrayList<AmphurBean> semester_amphurList = new ArrayList<AmphurBean>(); 
			AmphurSelectListDao semester_amphurSelectListDao = new AmphurSelectListDao();
			semester_amphurList = semester_amphurSelectListDao.getAmphurList(semester_address.getProvinceid());
			
			ArrayList<DistrictBean> semester_districtList = new ArrayList<DistrictBean>(); 
			DistrictSelectListDao semester_districtSelectListDao = new DistrictSelectListDao();
			semester_districtList = semester_districtSelectListDao.getDistrictList(semester_address.getAmphurid());
			
			request.setAttribute("listProvince_semester_address", semester_provinceList);
			request.setAttribute("listAmphur_semester_address", semester_amphurList);
			request.setAttribute("listDistrict_semester_address", semester_districtList);
			
			session.setAttribute("amphur_semester_address_id", semester_address.getAmphurid());
			session.setAttribute("amphur_semester_address_name", semester_address.getAmphurname());
			session.setAttribute("district_semester_address_id", semester_address.getDistrictid());
			session.setAttribute("district_semester_address_name", semester_address.getDistrictname());
			}
			//  # semester_address
			
			// parent_address
			{
			ArrayList<ProvinceBean> parent_provinceList = new ArrayList<ProvinceBean>(); 
			ProvinceSelectListDao parent_provinceSelectListDao = new ProvinceSelectListDao();
			parent_provinceList = parent_provinceSelectListDao.getProvinceList();
			
			ArrayList<AmphurBean> parent_amphurList = new ArrayList<AmphurBean>(); 
			AmphurSelectListDao parent_amphurSelectListDao = new AmphurSelectListDao();
			parent_amphurList = parent_amphurSelectListDao.getAmphurList(parent_address.getProvinceid());
			
			ArrayList<DistrictBean> parent_districtList = new ArrayList<DistrictBean>(); 
			DistrictSelectListDao parent_districtSelectListDao = new DistrictSelectListDao();
			parent_districtList = parent_districtSelectListDao.getDistrictList(parent_address.getAmphurid());
			
			request.setAttribute("listProvince_parent_address", parent_provinceList);
			request.setAttribute("listAmphur_parent_address", parent_amphurList);
			request.setAttribute("listDistrict_parent_address", parent_districtList);
			
			session.setAttribute("amphur_parent_address_id", parent_address.getAmphurid());
			session.setAttribute("amphur_parent_address_name", parent_address.getAmphurname());
			session.setAttribute("district_parent_address_id", parent_address.getDistrictid());
			session.setAttribute("district_parent_address_name", parent_address.getDistrictname());
			}
			//  # parent_address
			
			// family
			FamilyBean father_family = new FamilyBean();
			FamilyBean mother_family = new FamilyBean();
			FamilyBean parent_family = new FamilyBean();
			TableFamilyDao tableFamilyDao = new TableFamilyDao();
			father_family = tableFamilyDao.SelectFamilyType(keyProfile, "father_family");
			mother_family = tableFamilyDao.SelectFamilyType(keyProfile, "mother_family");
			parent_family = tableFamilyDao.SelectFamilyType(keyProfile, "parent_family");
			request.setAttribute("father_family", father_family);
			request.setAttribute("mother_family", mother_family);
			request.setAttribute("parent_family", parent_family);
			
			doViewDataStudent(request, response);
		}
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter(); 
		HttpSession session = request.getSession();
		
		boolean checkReport = false;
		String UserID = session.getAttribute("UserID").toString();
		String action = request.getParameter("action");
		String action_profile = request.getParameter("action_profile");
		String address = request.getParameter("action_address");
		String family = request.getParameter("action_family");
		
		// get select list
		if("getDivision".equals(action)){
			
			String FacID = request.getParameter("FacID");
			DivisionSelectListDao divisionSelectListDao = new DivisionSelectListDao();
			ArrayList<DivisionBean> listDivision = new ArrayList<DivisionBean>();
			listDivision = divisionSelectListDao.getDivisionList(Integer.parseInt(FacID));
			request.setAttribute("listDivision", listDivision);

			session.setAttribute("divID", 0);
			session.setAttribute("divName", 0);       //  session
			doViewDivisionList(request, response);
			return;
		}
		
		// get select list Amphur_original
		else if("clickProvince_original".equals(action)){
			String ProvinceID_original = request.getParameter("ProvinceID_original");
			AmphurSelectListDao amphurSelectListDao = new AmphurSelectListDao();
			ArrayList<AmphurBean> amphurBeans = new ArrayList<AmphurBean>();
			amphurBeans = amphurSelectListDao.getAmphurList(Integer.parseInt(ProvinceID_original));
			request.setAttribute("listAmphur_original_address", amphurBeans);
			session.setAttribute("amphur_original_address_id", 0);
			session.setAttribute("amphur_original_address_name", 0);       //  session
			doViewAmphur_originalList(request, response);
			return;
		}
		
		//get select list District_original
		else if("clickAmphur_original".equals(action)){
			String AmphurID_original = request.getParameter("AmphurID_original");
			DistrictSelectListDao districtSelectListDao = new DistrictSelectListDao();
			ArrayList<DistrictBean> districtBeans = new ArrayList<DistrictBean>();
			districtBeans = districtSelectListDao.getDistrictList(Integer.parseInt(AmphurID_original));
			request.setAttribute("listDistrict_original_address", districtBeans);
			session.setAttribute("district_original_address_id", 0);
			session.setAttribute("district_original_address_name", 0);       //  session
			doViewDistrict_originalList(request, response);
			return;
		}
		
		
		// get select list Amphur_semester
		else if("clickProvince_semester".equals(action)){
			String ProvinceID_semester = request.getParameter("ProvinceID_semester");
			AmphurSelectListDao amphurSelectListDao = new AmphurSelectListDao();
			ArrayList<AmphurBean> amphurBeans = new ArrayList<AmphurBean>();
			amphurBeans = amphurSelectListDao.getAmphurList(Integer.parseInt(ProvinceID_semester));
			request.setAttribute("listAmphur_semester_address", amphurBeans);
			session.setAttribute("amphur_semester_address_id", 0);
			session.setAttribute("amphur_semester_address_name", 0);       //  session
			doViewAmphur_semesterList(request, response);
			return;
		}
		//get select list District_semester
		else if("clickAmphur_semester".equals(action)){
			String AmphurID_semester = request.getParameter("AmphurID_semester");
			DistrictSelectListDao districtSelectListDao = new DistrictSelectListDao();
			ArrayList<DistrictBean> districtBeans = new ArrayList<DistrictBean>();
			districtBeans = districtSelectListDao.getDistrictList(Integer.parseInt(AmphurID_semester));
			request.setAttribute("listDistrict_semester_address", districtBeans);
			session.setAttribute("district_semester_address_id", 0);
			session.setAttribute("district_semester_address_name", 0);       //  session
			doViewDistrict_semesterlList(request, response);
			return;
		}
		
		// get select list Amphur_parent
		else if("clickProvince_parent".equals(action)){
			String ProvinceID_parent = request.getParameter("ProvinceID_parent");
			AmphurSelectListDao amphurSelectListDao = new AmphurSelectListDao();
			ArrayList<AmphurBean> amphurBeans = new ArrayList<AmphurBean>();
			amphurBeans = amphurSelectListDao.getAmphurList(Integer.parseInt(ProvinceID_parent));
			request.setAttribute("listAmphur_parent_address", amphurBeans);
			session.setAttribute("amphur_parent_address_id", 0);
			session.setAttribute("amphur_parent_address_name", 0);       //  session
			doViewAmphur_parentList(request, response);
			return;
		}
		//get select list District_parent
		else if("clickAmphur_parent".equals(action)){
			String AmphurID_parent = request.getParameter("AmphurID_parent");
			DistrictSelectListDao districtSelectListDao = new DistrictSelectListDao();
			ArrayList<DistrictBean> districtBeans = new ArrayList<DistrictBean>();
			districtBeans = districtSelectListDao.getDistrictList(Integer.parseInt(AmphurID_parent));
			request.setAttribute("listDistrict_parent_address", districtBeans);
			session.setAttribute("district_parent_address_id", 0);
			session.setAttribute("district_parent_address_name", 0);       //  session
			doViewDistrict_parentlList(request, response);
			return;
		}

		// update  tb_user
		else if("update_tb_user".equals(action)){
			UserBean userBean = new UserBean();
			userBean.setFirstname_th(request.getParameter("FirstName_th_student").toString());
			userBean.setLastname_th(request.getParameter("LastName_th_student").toString());
			userBean.setFirstname_eng(request.getParameter("FirstName_eng_student").toString());
			userBean.setLastname_eng(request.getParameter("LastName_eng_student").toString());
			userBean.setFacid(Integer.parseInt(request.getParameter("FacID").toString()));
			userBean.setDivid(Integer.parseInt(request.getParameter("DivID").toString()));
			userBean.setId(Integer.parseInt(request.getParameter("UserID").toString()));
			
			TableUserDao tableUserDao = new TableUserDao();
			tableUserDao.updateUser(userBean);
			out.print("update_tb_user"); 
		}
		

		if("profile_user".equals(action_profile)){
			
			ProfileBean profileBean = new ProfileBean();
			TableProfileDao tableProfileDao = new TableProfileDao();
			
			// profile  data student
			profileBean.setUserid(Integer.parseInt(request.getParameter("UserID").toString()));
			profileBean.setId_card(request.getParameter("Id_card").toString());
			profileBean.setIssue_at(request.getParameter("Issue_at").toString());
			profileBean.setIssue_date(request.getParameter("Issue_date").toString());
			profileBean.setExpiry_date(request.getParameter("Expiry_date").toString());
			profileBean.setRace(request.getParameter("Race").toString());
			profileBean.setNationality(request.getParameter("Nationality").toString());
			profileBean.setReligion(request.getParameter("Religion").toString());
			profileBean.setAge(request.getParameter("Age_student").toString());
			profileBean.setBirthday(request.getParameter("Birthday").toString());
			profileBean.setPlace_birth(request.getParameter("Place_birth").toString());
			profileBean.setSex(request.getParameter("Sex").toString());
			profileBean.setHeight(request.getParameter("Height").toString());
			profileBean.setWeight(request.getParameter("Weight").toString());
			profileBean.setCongenital_disease(request.getParameter("Congenital_disease").toString());
			
			profileBean.setClassyear(request.getParameter("ClassYear").toString());
			profileBean.setGroupstudent(request.getParameter("GroupStudent").toString());
			profileBean.setTitleid(Integer.parseInt(request.getParameter("TitleID_Advisor").toString()));
			profileBean.setFirstnameadvisor(request.getParameter("firstname_advisor").toString());
			profileBean.setLastnameadvisor(request.getParameter("lastname_advisor").toString());
			profileBean.setGrade(request.getParameter("Grade").toString());
			profileBean.setGradetotal(request.getParameter("GradeTotal").toString());
			
			if(tableProfileDao.CheckProfile(profileBean.getUserid())){
				// update
				tableProfileDao.UpdateProfile(profileBean);
				System.out.println("true update profile");
				
			}else{
				System.out.println("false insert profile");
				// insert
				tableProfileDao.InsertProfile(profileBean);

			}

		}
		
		
		TableProfileDao checkKeyProfile = new TableProfileDao();
		int keyProfile = checkKeyProfile.getKeyIDProfile(Integer.parseInt(request.getParameter("UserID").toString()));
		
		// tb_address
		if("address".equals(address)){
			
			TableAddressDao tableAddressDao = new TableAddressDao();
			
			 boolean check =   tableAddressDao.CheckAddress(keyProfile);
			
			for(int i=1; i<=3; i++){
				AddressBean addressBean = new AddressBean();
				addressBean.setId_num(request.getParameter("Id_num"+i).toString());
				addressBean.setNum_mu(request.getParameter("Num_Mu"+i).toString());
				addressBean.setRoad(request.getParameter("Road"+i).toString());
				addressBean.setProvinceid(Integer.parseInt(request.getParameter("ProvinceID"+i).toString()));
				addressBean.setAmphurid(Integer.parseInt(request.getParameter("AmphurID"+i).toString()));
				addressBean.setDistrictid(Integer.parseInt(request.getParameter("DistrictID"+i).toString()));
				addressBean.setPostcode(request.getParameter("Postcode"+i).toString());
				addressBean.setTelephone(request.getParameter("Telephone"+i).toString());
				addressBean.setMobile(request.getParameter("Mobile"+i).toString());
				addressBean.setFax(request.getParameter("Fax"+i).toString());
				addressBean.setEmail(request.getParameter("Email"+i).toString());
				
				if(i == 1){
					addressBean.setType("original_address");
				}else if(i == 2){
					addressBean.setType("semester_address");
				}else if(i == 3){
					addressBean.setType("parent_address");
				}
				addressBean.setProfilelid(keyProfile);
				
				
				if(check){
					System.out.println("true update address");
					tableAddressDao.updateAddress(addressBean);
				}else{
					//false
					System.out.println("false insert address");
					tableAddressDao.InsertAddress(addressBean);
				}
			}
		}
		
		// tb_family
		if("family".equals(family)){

			TableFamilyDao tableFamilyDao = new TableFamilyDao();
			boolean check = tableFamilyDao.CheckFamily(keyProfile);
			
			for(int i = 1; i<=3; i++){
				FamilyBean familyBean = new FamilyBean();
				
				if(i == 1){
					familyBean.setTitleid(Integer.parseInt(request.getParameter("TitleID_th_family_father").toString()));
					familyBean.setFirstname(request.getParameter("FirstName_family_father").toString());
					familyBean.setLastname(request.getParameter("LastName_family_father").toString());
					familyBean.setAge(request.getParameter("Age_family_father").toString());
					familyBean.setOccupation(request.getParameter("Occupation_family_father").toString());
					familyBean.setType("father_family");
					
				}else if(i == 2){
					familyBean.setTitleid(Integer.parseInt(request.getParameter("TitleID_th_family_mother").toString()));
					familyBean.setFirstname(request.getParameter("FirstName_family_mother").toString());
					familyBean.setLastname(request.getParameter("LastName_family_mother").toString());
					familyBean.setAge(request.getParameter("Age_family_mother").toString());
					familyBean.setOccupation(request.getParameter("Occupation_family_mother").toString());
					familyBean.setType("mother_family");
					
				}else if(i == 3){
					familyBean.setTitleid(Integer.parseInt(request.getParameter("TitleID_th_family_parent").toString()));
					familyBean.setFirstname(request.getParameter("FirstName_family_parent").toString());
					familyBean.setLastname(request.getParameter("LastName_family_parent").toString());
					familyBean.setRelation(request.getParameter("RelationID_parent").toString());
					familyBean.setOccupation(request.getParameter("Occupation_parent").toString());
					familyBean.setPlace_occupation(request.getParameter("PlaceOccupation_parent").toString());
					familyBean.setType("parent_family");
				}
								
					familyBean.setProfileid(keyProfile);
					
					if(check){
						// update
						System.out.println("ture update family");
						tableFamilyDao.updateFamily(familyBean);
						checkReport = true;
					}else{
						//false
						System.out.println("false insert family");
						tableFamilyDao.InsertFamily(familyBean);
					}
			}	
			
		}
		
		/* report */
		if(checkReport){
			int userid = Integer.parseInt(UserID);
			TableCoop02Dao tableCoop02Dao = new TableCoop02Dao();
			TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
			if(tableCoop02Dao.CheckCoop02(userid)){
				reportCoop02(request, userid);
				System.out.println("Update Report coop02");
			}
			if(tableCoop03Dao.CheckCoop03(userid)){
				reportCoop03(request, userid);
				System.out.println("Update Report coop03");
			}
		}
		/* #report */

	}
	
	
	private void doViewDataStudent(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/views/pages/student/data_student.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void doViewDivisionList(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/division_list.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	private void doViewAmphur_originalList(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/amphur/amphur_original_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void doViewAmphur_semesterList(HttpServletRequest request, HttpServletResponse response) {

		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/amphur/amphur_semester_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void doViewAmphur_parentList(HttpServletRequest request, HttpServletResponse response) {

		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/amphur/amphur_parent_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void doViewDistrict_originalList(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/district/district_original_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void doViewDistrict_semesterlList(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/district/district_semester_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void doViewDistrict_parentlList(HttpServletRequest request, HttpServletResponse response) {
		RequestDispatcher rd = request.getRequestDispatcher("/include/select-list/district/district_parent_address.jsp");
		try {
			rd.forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	

	/* report coop02 and coop03 */
	private void reportCoop02(HttpServletRequest request,int userid) {
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();
		userBean = tableUserDao.getTableUser(userid);
		
		TableProfileDao tableProfileDao = new TableProfileDao();
		ProfileBean profileBean = new ProfileBean();
		TableAddressDao tableAddressDao = new TableAddressDao();
		AddressBean addressBean1 = new AddressBean();
		AddressBean addressBean2 = new AddressBean();
		AddressBean addressBean3 = new AddressBean();
		TableFamilyDao tableFamilyDao = new TableFamilyDao();
		FamilyBean familyBean = new FamilyBean();
		
		// tb_profile, tb_address  , tb_family >>tye  parent_family
		profileBean = tableProfileDao.SelectProfile(userid);
		addressBean1 = tableAddressDao.SelectAddressType(profileBean.getId(), "original_address");
		addressBean1.setAmphurname(subString(addressBean1.getAmphurname()));
		addressBean1.setDistrictname(subString(addressBean1.getDistrictname()));

		addressBean2 = tableAddressDao.SelectAddressType(profileBean.getId(), "semester_address");
		addressBean2.setAmphurname(subString(addressBean2.getAmphurname()));
		addressBean2.setDistrictname(subString(addressBean2.getDistrictname()));
		
		addressBean3 = tableAddressDao.SelectAddressType(profileBean.getId(), "parent_address");
		addressBean3.setAmphurname(subString(addressBean3.getAmphurname()));
		addressBean3.setDistrictname(subString(addressBean3.getDistrictname()));
		
		familyBean = tableFamilyDao.SelectFamilyType(profileBean.getId(), "parent_family");
		
		
		TableCoop02Dao tableCoop02Dao2 = new TableCoop02Dao();
		TableSelectJob02Dao tableSelectJob02Dao2 = new TableSelectJob02Dao();
		TableLanguage02Dao tableLanguage02Dao2 = new TableLanguage02Dao();
		Coop02Bean coop02Bean2 = new Coop02Bean();
		SelectJob02Bean selectJob02Bean2 = new SelectJob02Bean();
		Language02Bean language02Bean2 = new Language02Bean();
		
		// coop02, select, language
		coop02Bean2 = tableCoop02Dao2.SelectCoop02(userid);
		selectJob02Bean2 = tableSelectJob02Dao2.SelectJob02(coop02Bean2.getId());
		language02Bean2 = tableLanguage02Dao2.SelectLanguage02(coop02Bean2.getId());
		
		// date
	      Date date = new Date( );
	      SimpleDateFormat ft =  new SimpleDateFormat ("dd.MM.yyyy");
	      String dateText = ft.format(date);
	      String[] dateSplit = dateText.split("[.]");
	      String [] dateMonthNumCheck = {"01","02","03","04","05","06","07","08","09","10","11","12"};
	      String [] dateMonthStrCheck = {"�.�.","�.�.","��.�.","��.�.","�.�.","��.�.","�.�.","�.�.","�.�.","�.�.","�.�.","�.�."};
	      
	      String date_day = dateSplit[0];
	      for(int i=0; i<=8; i++){
	    	  if(dateMonthNumCheck[i].equals(date_day)){
	    		  date_day = Integer.toString(i+1);
	    	  }
	      }
	      
	      String date_month = dateSplit[1];
	      for(int i=0; i<12; i++){
	    	  if(dateMonthNumCheck[i].equals(date_month)){
	    		  date_month = dateMonthStrCheck[i];
	    	  }
	      }

	      String date_year = dateSplit[2];
		
		
		// save report  pdf,docx 
		ReportCoop02 reportCoop02 = new ReportCoop02();
		reportCoop02.insertCoop02Pdf(request,userBean,profileBean,addressBean1,addressBean2,addressBean3,familyBean,coop02Bean2,selectJob02Bean2,language02Bean2,date_day,date_month,date_year);
		//reportCoop02.insertCoop02Docx(request,userBean,profileBean,addressBean1,addressBean2,addressBean3,familyBean,coop02Bean2,selectJob02Bean2,language02Bean2);
		
	}
	
	private void reportCoop03(HttpServletRequest request,int userid) {
		// tb_user, tb_profile, tb_adddress, tb_family, coop03 all
		TableUserDao tableUserDao = new TableUserDao();
		UserBean userBean = new UserBean();
		userBean = tableUserDao.getTableUser(userid);
		
		TableProfileDao tableProfileDao = new TableProfileDao();
		ProfileBean profileBean = new ProfileBean();
		profileBean = tableProfileDao.SelectProfile(userid);
		
		// convert date
		String[] str1 = profileBean.getIssue_date().split("-");    //2016-11-20
		String[] str2 = profileBean.getExpiry_date().split("-");
		String[] str3 = profileBean.getBirthday().split("-");
		profileBean.setIssue_date(str1[2]+"/"+str1[1]+"/"+(Integer.parseInt(str1[0])+543));
		profileBean.setExpiry_date(str2[2]+"/"+str2[1]+"/"+(Integer.parseInt(str2[0])+543));
		profileBean.setBirthday(str3[2]+"/"+str3[1]+"/"+(Integer.parseInt(str3[0])+543));
		
		TableAddressDao tableAddressDao = new TableAddressDao();
		List<AddressBean> addressBeanList = new ArrayList<AddressBean>();
		addressBeanList.add(tableAddressDao.SelectAddressType(profileBean.getId(), "original_address"));
		addressBeanList.add(tableAddressDao.SelectAddressType(profileBean.getId(), "semester_address"));
		addressBeanList.add(tableAddressDao.SelectAddressType(profileBean.getId(), "parent_address"));
		
		
		TableFamilyDao tableFamilyDao = new TableFamilyDao();
		List<FamilyBean> familyBeanList = new ArrayList<FamilyBean>();
		familyBeanList.add(tableFamilyDao.SelectFamilyType(profileBean.getId(), "father_family"));
		familyBeanList.add(tableFamilyDao.SelectFamilyType(profileBean.getId(), "mother_family"));
		familyBeanList.add(tableFamilyDao.SelectFamilyType(profileBean.getId(), "parent_family"));

		
		TableCoop03Dao tableCoop03Dao = new TableCoop03Dao();
		Coop03Bean coop03Bean = new Coop03Bean();
		int Coop03ID = tableCoop03Dao.getKeyIDCoop03(userid);
		coop03Bean = tableCoop03Dao.SelectCoop03(userid);
		
		TableEducationDao tableEducationDao = new TableEducationDao();
		List<EducationBean> educationBeansList = new ArrayList<EducationBean>();
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Primary"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Secondary"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "HighSchool"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Vocation_1"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Vocation_2"));
		educationBeansList.add(tableEducationDao.SelectEducation(Coop03ID, "Bachelor_degree"));
		
		TableRelativeDao tableRelativeDao = new TableRelativeDao();
		List<RelativeBean> relativeBeansList = new ArrayList<RelativeBean>();
		relativeBeansList.add(tableRelativeDao.SelectRelative(Coop03ID, "relative_1"));
		relativeBeansList.add(tableRelativeDao.SelectRelative(Coop03ID, "relative_2"));
		relativeBeansList.add(tableRelativeDao.SelectRelative(Coop03ID, "relative_3"));
		
		TableTrainingDao tableTrainingDao = new TableTrainingDao();
		List<TrainingBean> trainingBeansList = new ArrayList<TrainingBean>();
		trainingBeansList.add(tableTrainingDao.SelectTraining(Coop03ID, "training_1"));
		trainingBeansList.add(tableTrainingDao.SelectTraining(Coop03ID, "training_2"));
		trainingBeansList.add(tableTrainingDao.SelectTraining(Coop03ID, "training_3"));
		
		TableCareerDao tableCareerDao = new TableCareerDao();
		List<CareerBean> careerBeansList = new ArrayList<CareerBean>();
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_1"));
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_2"));
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_3"));
		careerBeansList.add(tableCareerDao.SelectCareer(Coop03ID, "career_4"));
		
		TableActivityDao tableActivityDao = new TableActivityDao();
		List<ActivityBean> activityBeansList = new ArrayList<ActivityBean>();
		activityBeansList.add(tableActivityDao.SelectActivity(Coop03ID, "activity_1"));
		activityBeansList.add(tableActivityDao.SelectActivity(Coop03ID, "activity_2"));
		activityBeansList.add(tableActivityDao.SelectActivity(Coop03ID, "activity_3"));
		
		TableLanguage03Dao tableLanguage03Dao = new TableLanguage03Dao();
		Language03Bean language03Bean = new Language03Bean();
		language03Bean = tableLanguage03Dao.SelectLanguage03(Coop03ID);
		
		// save report  pdf,docx 
		ReportCoop03 reportCoop03 = new ReportCoop03();
		reportCoop03.insertCoop03Pdf(request,userBean,profileBean,addressBeanList,familyBeanList,coop03Bean,educationBeansList,relativeBeansList,trainingBeansList,careerBeansList,activityBeansList,language03Bean);
		//reportCoop03.insertCoop03Docx(request,userBean,profileBean,addressBeanList,familyBeanList,coop03Bean,educationBeansList,relativeBeansList,trainingBeansList,careerBeansList,activityBeansList,language03Bean);
	}
	/* report coop02 and coop03 */

	private String subString(String textData){
		String text = textData.trim();
		int count = 0;
		String data = "";
		String sub = ""+text.charAt(0);
	      if("*".equals(sub)){
	    	  //System.out.println(text.substring(1));
	    	  data = ""+text.substring(1);
	    	  count++;
	      }
	      
	      sub = ""+text.charAt(text.length()-1);
	      if("*".equals(sub)){
	    	  //System.out.println(text.substring(0,text.length()-1));
	    	  data = ""+text.substring(0,text.length()-1);
	    	  count++;
	      }
	      
	      if(count == 0){
	    	  data = ""+text;
	    	  //System.out.println(data);
	      }
		return data;
	}
	
}

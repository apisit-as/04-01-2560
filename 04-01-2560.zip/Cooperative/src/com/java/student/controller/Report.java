package com.java.student.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Report
 */
@WebServlet("/Report")
public class Report extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Report() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String userid = request.getParameter("userid");
		String studentid = request.getParameter("studentid");
		String action = request.getParameter("action");
		String root = request.getServletContext().getRealPath("/");
		File file = null;
		String nameFile = "";
		nameFile = studentid+"_"+userid;
		//System.out.println(nameFile);
		if(action.equals("pdfCoop02")){
			  try{
				  file = new File(root, "Upload/File/Report/PDF/"+nameFile+"_coop02.pdf");
				  boolean empty = file.length() == 0;
				 // System.out.println(empty);
				  if(empty){ 
					  out.print("isEmpty02");   // file Empty02  
					  return;
				  }else{
					  out.print("Upload/File/Report/PDF/"+nameFile+"_coop02.pdf"); // not file Empty02  
					  return;
				  }
			  	} catch (Exception e) {
			  		e.printStackTrace();
			  	}
		}else if(action.equals("pdfCoop03")){
			  try{
				  file = new File(root, "Upload/File/Report/PDF/"+nameFile+"_coop03.pdf");
				  boolean empty = file.length() == 0;
				  //System.out.println(empty);
				  if(empty){ 
					  out.print("isEmpty03");  // file Empty03  
					  return;
				  }else{
					  out.print("Upload/File/Report/PDF/"+nameFile+"_coop03.pdf");  // not file Empty03 
					  return;
				  }
			  	} catch (Exception e) {
			  		e.printStackTrace();
			  	}
		}
		
//		else if(action.equals("docxCoop02")){
//			  try{
//				  file = new File(root, "Upload/File/Report/DOCX/"+nameFile+"_coop02.docx");
//				  boolean empty = file.length() == 0;
//				  //System.out.println(empty);
//				  if(empty){ 
//					  out.print("isEmpty02");  // file Empty02
//					  return;
//				  }else{
//					  out.print("Upload/File/Report/DOCX/"+nameFile+"_coop02.docx");  // not file Empty02 
//					  return;
//				  }
//			  	} catch (Exception e) {
//			  		e.printStackTrace();
//			  	}
//		}
//		else if(action.equals("docxCoop03")){
//			  try{
//				  file = new File(root, "Upload/File/Report/DOCX/"+nameFile+"_coop03.docx");
//				  boolean empty = file.length() == 0;
//				  //System.out.println(empty);
//				  if(empty){ 
//					  out.print("isEmpty03");  // file Empty03
//					  return;
//				  }else{
//					  out.print("Upload/File/Report/DOCX/"+nameFile+"_coop03.docx");  // not file Empty03
//					  return;
//				  }
//			  	} catch (Exception e) {
//			  		e.printStackTrace();
//			  	}
//		}
	}

}

package com.java.student.bean;

public class Language02Bean {
	private int id;
	private String language_eng;
	private String leve_eng;
	private String language_jap;
	private String leve_jap;
	private String language_chi;
	private String leve_chi;
	private String language_other;
	private String leve_other;
	private String other;
	private int coop02id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLanguage_eng() {
		return language_eng;
	}
	public void setLanguage_eng(String language_eng) {
		this.language_eng = language_eng;
	}
	public String getLeve_eng() {
		return leve_eng;
	}
	public void setLeve_eng(String leve_eng) {
		this.leve_eng = leve_eng;
	}
	public String getLanguage_jap() {
		return language_jap;
	}
	public void setLanguage_jap(String language_jap) {
		this.language_jap = language_jap;
	}
	public String getLeve_jap() {
		return leve_jap;
	}
	public void setLeve_jap(String leve_jap) {
		this.leve_jap = leve_jap;
	}
	public String getLanguage_chi() {
		return language_chi;
	}
	public void setLanguage_chi(String language_chi) {
		this.language_chi = language_chi;
	}
	public String getLeve_chi() {
		return leve_chi;
	}
	public void setLeve_chi(String leve_chi) {
		this.leve_chi = leve_chi;
	}
	public String getLanguage_other() {
		return language_other;
	}
	public void setLanguage_other(String language_other) {
		this.language_other = language_other;
	}
	public String getLeve_other() {
		return leve_other;
	}
	public void setLeve_other(String leve_other) {
		this.leve_other = leve_other;
	}
	public String getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other = other;
	}
	public int getCoop02id() {
		return coop02id;
	}
	public void setCoop02id(int coop02id) {
		this.coop02id = coop02id;
	}

	
	
}

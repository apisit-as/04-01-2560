package com.java.student.bean;

public class ProfileBean {
	private int id;
	private String classyear;
	private String groupstudent;
	private int titleid;
	private String titlename_th;
	private String titlename_eng;
	private String firstnameadvisor;
	private String lastnameadvisor;
	private String grade;
	private String gradetotal;
	private String id_card;
	private String issue_at;
	private String issue_date;
	private String expiry_date;
	private String race;
	private String nationality;
	private String religion;
	private String age;
	private String birthday;
	private String place_birth;
	private String sex;
	private String height;
	private String weight;
	private String congenital_disease;
	private int userid;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClassyear() {
		return classyear;
	}
	public void setClassyear(String classyear) {
		this.classyear = classyear;
	}
	public String getGroupstudent() {
		return groupstudent;
	}
	public void setGroupstudent(String groupstudent) {
		this.groupstudent = groupstudent;
	}
	public int getTitleid() {
		return titleid;
	}
	public void setTitleid(int titleid) {
		this.titleid = titleid;
	}
	public String getTitlename_th() {
		return titlename_th;
	}
	public void setTitlename_th(String titlename_th) {
		this.titlename_th = titlename_th;
	}
	public String getTitlename_eng() {
		return titlename_eng;
	}
	public void setTitlename_eng(String titlename_eng) {
		this.titlename_eng = titlename_eng;
	}
	public String getFirstnameadvisor() {
		return firstnameadvisor;
	}
	public void setFirstnameadvisor(String firstnameadvisor) {
		this.firstnameadvisor = firstnameadvisor;
	}
	public String getLastnameadvisor() {
		return lastnameadvisor;
	}
	public void setLastnameadvisor(String lastnameadvisor) {
		this.lastnameadvisor = lastnameadvisor;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getGradetotal() {
		return gradetotal;
	}
	public void setGradetotal(String gradetotal) {
		this.gradetotal = gradetotal;
	}
	public String getId_card() {
		return id_card;
	}
	public void setId_card(String id_card) {
		this.id_card = id_card;
	}
	public String getIssue_at() {
		return issue_at;
	}
	public void setIssue_at(String issue_at) {
		this.issue_at = issue_at;
	}
	public String getIssue_date() {
		return issue_date;
	}
	public void setIssue_date(String issue_date) {
		this.issue_date = issue_date;
	}
	public String getExpiry_date() {
		return expiry_date;
	}
	public void setExpiry_date(String expiry_date) {
		this.expiry_date = expiry_date;
	}
	public String getRace() {
		return race;
	}
	public void setRace(String race) {
		this.race = race;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getReligion() {
		return religion;
	}
	public void setReligion(String religion) {
		this.religion = religion;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getPlace_birth() {
		return place_birth;
	}
	public void setPlace_birth(String place_birth) {
		this.place_birth = place_birth;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getCongenital_disease() {
		return congenital_disease;
	}
	public void setCongenital_disease(String congenital_disease) {
		this.congenital_disease = congenital_disease;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	


	
}

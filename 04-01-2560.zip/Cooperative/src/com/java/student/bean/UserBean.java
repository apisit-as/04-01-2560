package com.java.student.bean;


public class UserBean {
	private int id;
	private String studentid;
	private String username;
	private String password;
	private int titleid;
	private String titlename_th;
	private String titlename_eng;
	private String firstname_th;
	private String lastname_th;
	private String firstname_eng;
	private String lastname_eng;
	private int roleid;
	private String rolename;
	private int facid;
	private String facname;  
	private int divid;
	private String divname;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStudentid() {
		return studentid;
	}
	public void setStudentid(String studentid) {
		this.studentid = studentid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getTitleid() {
		return titleid;
	}
	public void setTitleid(int titleid) {
		this.titleid = titleid;
	}
	public String getTitlename_th() {
		return titlename_th;
	}
	public void setTitlename_th(String titlename_th) {
		this.titlename_th = titlename_th;
	}
	public String getTitlename_eng() {
		return titlename_eng;
	}
	public void setTitlename_eng(String titlename_eng) {
		this.titlename_eng = titlename_eng;
	}
	public String getFirstname_th() {
		return firstname_th;
	}
	public void setFirstname_th(String firstname_th) {
		this.firstname_th = firstname_th;
	}
	public String getLastname_th() {
		return lastname_th;
	}
	public void setLastname_th(String lastname_th) {
		this.lastname_th = lastname_th;
	}
	public String getFirstname_eng() {
		return firstname_eng;
	}
	public void setFirstname_eng(String firstname_eng) {
		this.firstname_eng = firstname_eng;
	}
	public String getLastname_eng() {
		return lastname_eng;
	}
	public void setLastname_eng(String lastname_eng) {
		this.lastname_eng = lastname_eng;
	}
	public int getRoleid() {
		return roleid;
	}
	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}
	public String getRolename() {
		return rolename;
	}
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
	public int getFacid() {
		return facid;
	}
	public void setFacid(int facid) {
		this.facid = facid;
	}
	public String getFacname() {
		return facname;
	}
	public void setFacname(String facname) {
		this.facname = facname;
	}
	public int getDivid() {
		return divid;
	}
	public void setDivid(int divid) {
		this.divid = divid;
	}
	public String getDivname() {
		return divname;
	}
	public void setDivname(String divname) {
		this.divname = divname;
	}

}

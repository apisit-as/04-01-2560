package com.java.student.dao;


import com.java.student.bean.UserBean;
import com.java.util.PreparedStatementUtil;


import java.sql.ResultSet;
import java.sql.SQLException;


public class LoginDao {

	public UserBean checkLogin(UserBean loginbean){

		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rec = null;
		UserBean bean = new UserBean();
		String sql = "SELECT tb_user.ID,"
				+ "tb_user.StudentID,"
				+ " tb_title.Name_th,"
				+ " tb_user.FirstName_th,"		
				+ " tb_user.LastName_th,"
				+ " tb_user.RoleID,"
				+ " tb_role.Name AS RoleName"
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title ON tb_user.TitleID = tb_title.ID"
				+ " JOIN tb_role  ON tb_user.RoleID = tb_role.ID"
				+ " WHERE tb_user.Username = :username and tb_user.Password = :password";
		try {
			prepareStatementUtil = new PreparedStatementUtil(sql);
			prepareStatementUtil.setString("username", loginbean.getUsername());
			prepareStatementUtil.setString("password", loginbean.getPassword());
			rec = prepareStatementUtil.executeQuery();
			while ((rec.next()) && (rec != null)) {
				bean.setId(rec.getInt("ID"));
				bean.setStudentid(rec.getString("StudentID"));
				bean.setTitlename_th(rec.getString("Name_th"));
				bean.setFirstname_th(rec.getString("FirstName_th"));
				bean.setLastname_th(rec.getString("LastName_th"));
				bean.setRoleid(rec.getInt("RoleID"));
				bean.setRolename(rec.getString("RoleName"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rec.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return bean;
	}	

}

package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.Coop03Bean;
import com.java.util.PreparedStatementUtil;

public class TableCoop03Dao {
	
	public Boolean CheckCoop03(int UserID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		Boolean value = false;
		String query = "SELECT True as isCoop03 FROM cooperative.tb_coop03 WHERE UserID = :userid LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("userid", UserID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isCoop03");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return value;
	}
	
	public void InsertCoop03(Coop03Bean  coop03Bean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "INSERT INTO tb_coop03(Num_relative,"
		   									+ "My_relative,"
		   									+ "Picture,"
		   									+ "UserID) "
					   		+ " VALUES(:num_relative,"  
					   				+ ":my_relative,"
					   				+ ":picture,"
					   				+ ":userid)";

		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("num_relative", coop03Bean.getNum_relative());
		   preparedStatementUtil.setString("my_relative", coop03Bean.getMy_relative());
		   preparedStatementUtil.setString("picture", coop03Bean.getPicture());
		   preparedStatementUtil.setInt("userid", coop03Bean.getUserid());

		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	
	
	public void UpdateCoop03(Coop03Bean coop03Bean){
		PreparedStatementUtil preparedStatementUtil = null;
	  
		  try{
		   String query = "UPDATE tb_coop03 SET "
		   				+ "Num_relative = :num_relative,"
		   				+ "My_relative = :my_relative,"
		   				+ "Picture = :picture "
		   				+ "WHERE UserID = :userid";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("num_relative", coop03Bean.getNum_relative());
		   preparedStatementUtil.setString("my_relative", coop03Bean.getMy_relative());
		   preparedStatementUtil.setString("picture", coop03Bean.getPicture());
		   preparedStatementUtil.setInt("userid", coop03Bean.getUserid());

		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		  }
	}
	
	public Coop03Bean SelectCoop03(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		Coop03Bean coop03Bean = new Coop03Bean();
		
		String query = "SELECT Num_relative,My_relative,Picture"
				+ " FROM tb_coop03"
				+ " WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				coop03Bean.setNum_relative(rs.getString("Num_relative"));
				coop03Bean.setMy_relative(rs.getString("My_relative"));
				coop03Bean.setPicture(rs.getString("Picture"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return coop03Bean;
	} 
	
	public String SelectPictureCoop03(int UserID){
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		String pic = "";
		
		String query = "SELECT Picture"
				+ " FROM tb_coop03"
				+ " WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				pic = rs.getString("Picture");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return pic;
	}
	
	
	public int getKeyIDCoop03(int UserID){
		
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		int key = 0;
		
		String query = "SELECT tb_coop03.ID FROM tb_coop03 WHERE UserID = :userid"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("userid", UserID);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				key = rs.getInt("ID");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return key;
	} 
}

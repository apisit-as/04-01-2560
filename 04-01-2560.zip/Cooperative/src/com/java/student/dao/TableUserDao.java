package com.java.student.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.student.bean.UserBean;
import com.java.util.PreparedStatementUtil;

public class TableUserDao {
	public UserBean getTableUser(int keyUserID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rec = null;
		UserBean bean = new UserBean();
		String sql = "SELECT tb_user.ID,tb_user.StudentID,"
				+ "tb_title.Name_th AS titleName_th,"
				+ "tb_user.FirstName_th,"
				+ "tb_user.LastName_th,"
				+ "tb_title.Name_eng AS titleName_eng,"
				+ "tb_user.FirstName_eng,"
				+ "tb_user.LastName_eng,"
				+ "tb_user.FacID,"
				+ "tb_user.DivID,"
				+ "tb_faculty.Name AS facName,"
				+ "tb_division.Name AS divName,"
				+ "tb_role.Name AS roleName"
				
				+ " FROM tb_user "
				+ " LEFT JOIN tb_title ON tb_user.TitleID = tb_title.ID"
				+ " JOIN tb_role  ON tb_user.RoleID = tb_role.ID"
				+ " LEFT JOIN tb_faculty ON tb_user.FacID = tb_faculty.ID"
				+ " LEFT JOIN tb_division ON tb_user.DivID = tb_division.ID"
				+ " WHERE tb_user.ID = :key";
		try {
			prepareStatementUtil = new PreparedStatementUtil(sql);
			prepareStatementUtil.setInt("key", keyUserID);

			rec = prepareStatementUtil.executeQuery();
			while ((rec.next()) && (rec != null)) {
				bean.setId(rec.getInt("ID"));
				bean.setStudentid(rec.getString("StudentID"));
				bean.setTitlename_th(rec.getString("titleName_th"));
				bean.setFirstname_th(rec.getString("FirstName_th"));
				bean.setLastname_th(rec.getString("LastName_th"));
				bean.setTitlename_eng(rec.getString("titleName_eng"));
				bean.setFirstname_eng(rec.getString("FirstName_eng"));
				bean.setLastname_eng(rec.getString("LastName_eng"));
				bean.setFacid(rec.getInt("FacID"));
				bean.setDivid(rec.getInt("DivID"));
				bean.setFacname(rec.getString("facName"));
				bean.setDivname(rec.getString("divName"));
				bean.setRolename(rec.getString("roleName"));
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rec.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return bean;
	}
	
	
	public void updateUser(UserBean userbean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_user SET "
		   				+ "FirstName_th = :firstName_th,"
		   				+ "LastName_th = :lastName_th,"
		   				+ "FirstName_eng = :firstName_eng,"
		   				+ "LastName_eng = :lastName_eng,"
		   				+ "FacID = :facID,"
		   				+ "DivID = :divID " 
		   				+ "WHERE tb_user.ID = :id";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("firstName_th", userbean.getFirstname_th());
		   preparedStatementUtil.setString("lastName_th", userbean.getLastname_th());
		   preparedStatementUtil.setString("firstName_eng", userbean.getFirstname_eng());
		   preparedStatementUtil.setString("lastName_eng", userbean.getLastname_eng());
		   preparedStatementUtil.setInt("facID", userbean.getFacid());
		   preparedStatementUtil.setInt("divID", userbean.getDivid());
		   preparedStatementUtil.setInt("id", userbean.getId());

		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
	
	public void addUser(UserBean userbean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "INSERT INTO tb_user(UserName,"
		   									+ "Password,"
		   									+ "StudentID,"
		   									+ "TitleID,"
		   									+ "FirstName_th,"
		   									+ "LastName_th,"
		   									+ "FirstName_eng,"
		   									+ "LastName_eng,"
		   									+ "RoleID) "
					   		+ " VALUES(:username,"
					   				+ ":password,"
					   				+ ":studentid,"
					   				+ ":titleid,"
					   				+ ":firstname_th,"
					   				+ ":lastname_th,"
					   				+ ":firstname_eng,"
					   				+ ":lastname_eng,"
					   				+ ":roleid)";
		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("username", userbean.getUsername());
		   preparedStatementUtil.setString("password", userbean.getPassword());
		   preparedStatementUtil.setString("studentid", userbean.getStudentid());
		   preparedStatementUtil.setInt("titleid", userbean.getTitleid());
		   preparedStatementUtil.setString("firstname_th", userbean.getFirstname_th());
		   preparedStatementUtil.setString("lastname_th", userbean.getLastname_th());
		   preparedStatementUtil.setString("firstname_eng", userbean.getFirstname_eng());
		   preparedStatementUtil.setString("lastname_eng", userbean.getLastname_eng());
		   preparedStatementUtil.setInt("roleid", userbean.getRoleid());
		   
		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
}

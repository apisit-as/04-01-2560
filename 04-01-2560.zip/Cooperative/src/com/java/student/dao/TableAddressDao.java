package com.java.student.dao;
import com.java.student.bean.AddressBean;
import com.java.util.PreparedStatementUtil;


import java.sql.ResultSet;
import java.sql.SQLException;

public class TableAddressDao {

	
	public Boolean CheckAddress(int profileID){
		
		PreparedStatementUtil prepareStatementUtil = null;
		ResultSet rs = null;
	
		Boolean value = false;
		String query = "SELECT True as isAddress FROM cooperative.tb_address WHERE ProfileID = :profileid LIMIT 1";
		
		try {
			prepareStatementUtil = new PreparedStatementUtil(query);
			prepareStatementUtil.setInt("profileid", profileID);
			rs = prepareStatementUtil.executeQuery();
			
			if(rs.next()){
				value = rs.getBoolean("isAddress");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				prepareStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return value;
	}	
	
	
	public void InsertAddress(AddressBean addressBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "INSERT INTO tb_address(Id_num,"
		   									+ "Num_Mu,"
		   									+ "Road,"
		   									+ "ProvinceID,"
		   									+ "AmphurID,"
		   									+ "DistrictID,"
		   									+ "Postcode,"
		   									+ "Telephone,"
		   									+ "Mobile,"
		   									+ "Fax,"
		   									+ "Email,"
		   									+ "Type,"
		   									+ "ProfileID) "
					   		+ " VALUES(:Id_num,"
					   				+ ":Num_Mu,"
					   				+ ":Road,"
					   				+ ":ProvinceID,"
					   				+ ":AmphurID,"
					   				+ ":DistrictID,"
					   				+ ":Postcode,"
					   				+ ":Telephone,"
					   				+ ":Mobile,"
					   				+ ":Fax,"
					   				+ ":Email,"
					   				+ ":Type,"
					   				+ ":ProfileID)";

		   preparedStatementUtil = new PreparedStatementUtil(query);
		   
		   preparedStatementUtil.setString("Id_num",addressBean.getId_num() );
		   preparedStatementUtil.setString("Num_Mu",addressBean.getNum_mu() );
		   preparedStatementUtil.setString("Road",addressBean.getRoad() );
		   preparedStatementUtil.setInt("ProvinceID",addressBean.getProvinceid());
		   preparedStatementUtil.setInt("AmphurID",addressBean.getAmphurid());
		   preparedStatementUtil.setInt("DistrictID",addressBean.getDistrictid());
		   preparedStatementUtil.setString("Postcode",addressBean.getPostcode() );
		   preparedStatementUtil.setString("Telephone",addressBean.getTelephone());
		   preparedStatementUtil.setString("Mobile",addressBean.getMobile() );
		   preparedStatementUtil.setString("Fax",addressBean.getFax() );
		   preparedStatementUtil.setString("Email",addressBean.getEmail() );
		   preparedStatementUtil.setString("Type",addressBean.getType() );
		   preparedStatementUtil.setInt("ProfileID",addressBean.getProfilelid());
		   
		   preparedStatementUtil.execute();   
		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}	
	
	
	
	public AddressBean SelectAddressType(int profileID,String type){
		
		PreparedStatementUtil preparedStatementUtil = null;
		ResultSet rs = null;;
		AddressBean addressBean = new AddressBean();
		
		String query = "SELECT Id_num,Num_Mu,Road,tb_address.ProvinceID,tb_address.AmphurID,tb_address.DistrictID,Postcode,"
				+ "Telephone,Mobile,Fax,Email,Type,"
				+ "tb_province.Name AS provinceName,"
				+ "tb_amphur.Name AS amphurName,"
				+ "tb_district.Name AS districtName,"
				+ "tb_address.ProfileID"
				+ " FROM tb_address"
				+ " LEFT JOIN tb_province on tb_province.ID = tb_address.ProvinceID"
				+ " LEFT JOIN tb_amphur on tb_amphur.ID = tb_address.AmphurID"
				+ " LEFT JOIN tb_district on tb_district.ID = tb_address.DistrictID"
				+ " WHERE tb_address.ProfileID = :profileid && tb_address.Type = :type"; 
		try {
			preparedStatementUtil = new PreparedStatementUtil(query);
			preparedStatementUtil.setInt("profileid", profileID);
			preparedStatementUtil.setString("type", type);
			rs = preparedStatementUtil.executeQuery();
			
			if(rs.next()){
				addressBean.setId_num(rs.getString("Id_num"));
				addressBean.setNum_mu(rs.getString("Num_Mu"));
				addressBean.setRoad(rs.getString("Road"));
				addressBean.setProvinceid(rs.getInt("ProvinceID"));
				addressBean.setAmphurid(rs.getInt("AmphurID"));
				addressBean.setDistrictid(rs.getInt("DistrictID"));
				addressBean.setPostcode(rs.getString("Postcode"));
				addressBean.setTelephone(rs.getString("Telephone"));
				addressBean.setMobile(rs.getString("Mobile"));
				addressBean.setFax(rs.getString("Fax"));
				addressBean.setEmail(rs.getString("Email"));
				addressBean.setType(rs.getString("Type"));
				addressBean.setProvincename(rs.getString("provinceName"));
				addressBean.setAmphurname(rs.getString("amphurName"));
				addressBean.setDistrictname(rs.getString("districtName"));
				addressBean.setProfilelid(rs.getInt("ProfileID"));
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return addressBean;
	} 
	
	
	public void updateAddress(AddressBean addressBean){
		PreparedStatementUtil preparedStatementUtil = null;
		  
		  try{
		   String query = "UPDATE tb_address SET "
		   				+ "Id_num = :id_num,"
		   				+ "Num_Mu = :num_mu,"
		   				+ "Road = :road,"
		   				+ "ProvinceID = :provinceid,"
		   				+ "AmphurID = :amphurid,"
		   				+ "DistrictID = :districtid, " 
		   				+ "Postcode = :postcode, " 
		   				+ "Telephone = :telephone, " 
		   				+ "Mobile = :mobile, " 
		   				+ "Fax = :fax, " 
		   				+ "Email = :email " 
		   				+ "WHERE tb_address.ProfileID = :profileid && tb_address.Type = :type ";

		   preparedStatementUtil = new PreparedStatementUtil(query);

		   preparedStatementUtil.setString("id_num", addressBean.getId_num());
		   preparedStatementUtil.setString("num_mu", addressBean.getNum_mu());
		   preparedStatementUtil.setString("road", addressBean.getRoad());
		   preparedStatementUtil.setInt("provinceid", addressBean.getProvinceid());
		   preparedStatementUtil.setInt("amphurid", addressBean.getAmphurid());
		   preparedStatementUtil.setInt("districtid", addressBean.getDistrictid());
		   preparedStatementUtil.setString("postcode", addressBean.getPostcode());
		   preparedStatementUtil.setString("telephone", addressBean.getTelephone());
		   preparedStatementUtil.setString("mobile", addressBean.getMobile());
		   preparedStatementUtil.setString("fax", addressBean.getFax());
		   preparedStatementUtil.setString("email", addressBean.getEmail());
		   preparedStatementUtil.setInt("profileid", addressBean.getProfilelid());
		   preparedStatementUtil.setString("type", addressBean.getType());
		   
		   preparedStatementUtil.execute();
		   		   
		  }catch(Exception e){
		   e.printStackTrace();
		  }finally{
		   if(preparedStatementUtil != null)
			try {
				preparedStatementUtil.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
	}
	
}

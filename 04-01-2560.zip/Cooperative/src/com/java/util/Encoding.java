package com.java.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Encoding {
	private MessageDigest md;
	private String output = "";
	public String Encode(String message) {
	        try {
	            md = MessageDigest.getInstance("SHA-256");

	            md.update(message.getBytes());
	            byte[] mb = md.digest();
	            output = "";
	            for (int i = 0; i < mb.length; i++) {
	                byte temp = mb[i];
	                String s = Integer.toHexString(new Byte(temp));
	                while (s.length() < 2) {
	                    s = "0" + s;
	                }
	                s = s.substring(s.length() - 2);
	                output += s;
	            }
	        } catch (NoSuchAlgorithmException e) {
	            System.out.println("ERROR: " + e.getMessage());
	        }
	        return output;
	}
	
}
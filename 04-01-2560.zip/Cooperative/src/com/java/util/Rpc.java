﻿package com.java.util;

import java.net.URL;
import java.util.Map;

import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

public class Rpc {

	private String prename;
	private String studentId;
	private String firstName;
	private String lastName;
	private String firstNameE;
	private String lastNameE;
	private Boolean check;

	public Rpc(String user, String pass) {
		try {
				XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
				config.setServerURL(new URL("http://apps.kkc.rmuti.ac.th/webservice/xmlrpc/"));
				XmlRpcClient client = new XmlRpcClient();
				client.setConfig(config);
	
				Object[] params = new Object[] { user, pass };
				Boolean result = (Boolean) client.execute("isPermit", params);
	
				System.out.println("LDAP Permision: " + result);

				check = result;
				if (check) { // true , false
	
					Map<String, String> map = (Map<String, String>) client.execute("getAll", params);
//					prename = map.get("prename");
//					studentId = map.get("studentId");
//					firstName = map.get("firstName");
//					lastName = map.get("lastName");
//					firstNameE = map.get("firstNameE");
//					lastNameE = map.get("lastNameE");
					
					/*Test*/
					prename = map.get("prename");
					studentId = map.get("studentId");
					//studentId = null;
					firstName = map.get("firstName");
					lastName = map.get("lastName");
					firstNameE = map.get("firstNameE");
					lastNameE = map.get("lastNameE");
					
					System.out.println(prename);
					System.out.println(studentId);
					System.out.println(firstName);
					System.out.println(lastName);
					System.out.println(firstNameE);
					System.out.println(lastNameE);
					System.out.println(map.get("uidNumber"));
					System.out.println(map.get("uid"));
					System.out.println(map.get("prenameId"));
					System.out.println(map.get("accountStatus"));
					System.out.println(map.get("member"));
					System.out.println(map.get("ssn"));
					System.out.println(map.get("campusId"));

					
				}
		} catch (Exception e) {
			e.printStackTrace();
			check = false;
		}
	}

	public String getPrename() {
		return prename;
	}

	public String getStudentId() {
		return studentId;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}
	
	public Boolean getCheck(){
		return check;
	}
	public String getFirstNameE() {
		return firstNameE;
	}

	public void setFirstNameE(String firstNameE) {
		this.firstNameE = firstNameE;
	}

	public String getLastNameE() {
		return lastNameE;
	}

	public void setLastNameE(String lastNameE) {
		this.lastNameE = lastNameE;
	}

}

function readURL(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();

		reader.onload = function(e) {
			$('#Picture').attr('src', e.target.result);
		}

		reader.readAsDataURL(input.files[0]);
	}
}

// onchange
$("#uploadBtn").change(function(e) {
	$("#uploadFile").val(this.value);
	if ($("#uploadFile").val() != '') {
		var files = e.originalEvent.target.files;
		var t = files[0].type;
		var s = files[0].size;

		console.log(t);
		console.log(s);

		if (t == "image/jpeg" || t == "image/png") {
			// <= 2mb.
			if (s <= 2048000) {
				readURL(this);
			} else {
				$("#uploadBtn").val('');
				$("#uploadFile").val('');
				$('#Picture').attr('src', 'assets/img/uploaduserprofile.png');		
				bootbox.alert({					
					title: "<span class='glyphicon glyphicon-alert'></span>&nbsp;&nbsp;กรุณาเลือกไฟล์ภาพใหม่ !!",
				    message: "ขนาดภาพต้องไม่เกิน 2mb !!",
				    size: 'small'
				});
			}

		} else {
			bootbox.alert({					
				title: "<span class='glyphicon glyphicon-alert'></span>&nbsp;&nbsp;กรุณาเลือกไฟล์ภาพใหม่ !!",
			    message: " กรุณาเลือกไฟลืภาพเป็น<br>jpeg,png เท่านั้น !!",
			    size: 'small'
			});
			
			$("#uploadBtn").val('');
			$("#uploadFile").val('');
			$('#Picture').attr('src', 'assets/img/uploaduserprofile.png');
		}

	} else {
		$("#uploadBtn").val('');
		$("#uploadFile").val('');
		$('#Picture').attr('src', 'assets/img/uploaduserprofile.png');
	}
});

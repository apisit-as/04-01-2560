
//////////////////////////////////////////////////////////
/*page coop03.jsp*/

//รับเฉพาะ  ตัวเลข ขีดละ
$('#relative_Age1,#relative_Age2,#relative_Age3,#educatiion_year_attended1,#educatiion_year_graduated1,#educatiion_year_attended2,#educatiion_year_graduated2,#educatiion_year_attended3,#educatiion_year_graduated3,#educatiion_year_attended4,#educatiion_year_graduated4,#educatiion_year_attended5,#educatiion_year_graduated5,#educatiion_year_attended6,#educatiion_year_graduated6').keyup(function () { 
    this.value = this.value.replace(/[^0-9\-]/g,'');
});

/*รับเฉพาะ ตัวอักษร th ขีดละ*/
$('#ohter').keyup(function () { 
	 this.value = this.value.replace(/[^ ๅภถุึคตจขชๆไำพะัีรนยบลฃฟหกดเ้่าสวงผปแอิืทมใฝ๑๒๓๔ู฿๕๖๗๘๙๐ฎฑธํ๊ณฯญฐฅฤฆฏโฌ็๋ษศซฉฮฺ์ฒฬฦ\-]/g,''); 
	});